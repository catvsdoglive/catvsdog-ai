// aiDatabase.js
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const DB_PATH = process.env.DB_PATH
  ? path.resolve(__dirname, process.env.DB_PATH)
  : path.resolve(__dirname, 'database', 'ai_prediction.db');

const db = new sqlite3.Database(DB_PATH, async (err) => {
  if (err) {
    console.error(err.message);
  } else {
    console.log('Connected to sqlite3 database');

    // 1) Enable Write-Ahead Logging:
    db.run("PRAGMA journal_mode = WAL;", [], (pragmaErr, result) => {
      if (pragmaErr) {
        console.error("Failed to enable WAL mode:", pragmaErr.message);
      } else {
        console.log("SQLite journal_mode set to WAL");
      }
    });

    // 2) Wait up to 5 seconds if DB is locked 
    db.configure('busyTimeout', 5000);
  }
});

function runAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}

function getAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function allAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

/**
 * In-memory cache for lifetime baselines:
 * { catRate, dogRate, otherRate, lastUpdate }
 */
let lifetimeBaselineCache = {
  catRate: 0,
  dogRate: 0,
  otherRate: 0,
  lastUpdate: null
};

/**
 * Get a JS‐computed UTC timestamp string: "YYYY-MM-DD HH:MM:SS"
 */
function nowUtcString() {
  return new Date().toISOString().slice(0, 19).replace('T', ' ');
}

/**
 * Returns active hours with sessions properly clipped to the window.
 * This fixes the critical bug where full session durations were summed.
 */
async function getActiveHoursRange(windowStart, windowEnd) {
  // Clip each session to the overlap with [windowStart, windowEnd).
  const row = await getAsync(`
    SELECT COALESCE(SUM(
      MAX(0,
        (julianday(MIN(COALESCE(end_ts, ?), ?)) - julianday(MAX(start_ts, ?))) * 24.0
      )
    ),0) AS activeHours
    FROM server_sessions
    WHERE start_ts < ?
      AND COALESCE(end_ts, ?) > ?
  `, [windowEnd, windowEnd, windowStart, windowEnd, windowEnd, windowStart]);
  return row.activeHours;
}

/**
 * Returns active hours based on session intervals within the last `hours` hours.
 * Now uses the fixed getActiveHoursRange function.
 */
async function getActiveHours(hours) {
  const windowEnd   = nowUtcString();
  const windowStart = new Date(Date.now() - hours * 3600_000)
    .toISOString().slice(0, 19).replace('T', ' ');
  return getActiveHoursRange(windowStart, windowEnd);
}

/**
 * initializeDatabase()
 *   - Creates (if not exists):
 *       • time_series_5m (5-minute buckets)
 *       • baseline_tracker (cumulative buckets + rates)
 *       • server_heartbeat
 *       • server_sessions (NEW)
 *       • forecasts (NEW - for Holt-Winters)
 *       • residuals (NEW - for tracking forecast errors)
 *       • indexes
 *   - Ensures baseline_tracker has exactly one row, with last_updated set to JS UTC.
 */
// File: aiDatabase.js  (Node 18+, sqlite3 5.x)
// Replace ONLY the initializeDatabase() body with the following.
async function initializeDatabase() {
  try {
    // 1) time_series_5m: one row per UTC-aligned 5m bucket
    await runAsync(`
      CREATE TABLE IF NOT EXISTS time_series_5m (
        bucket_start     TEXT    PRIMARY KEY,
        cat_count        INTEGER NOT NULL DEFAULT 0,
        dog_count        INTEGER NOT NULL DEFAULT 0,
        other_count      INTEGER NOT NULL DEFAULT 0,
        prediction_count INTEGER NOT NULL DEFAULT 0,
        pump_count       INTEGER NOT NULL DEFAULT 0
      )
    `);

    // 1a) Indexes for time_series_5m
    await runAsync(`CREATE INDEX IF NOT EXISTS idx_ts5m_bucket ON time_series_5m(bucket_start)`);
    await runAsync(`
      CREATE INDEX IF NOT EXISTS idx_ts5m_cat_dog_other
      ON time_series_5m(bucket_start, cat_count, dog_count, other_count)
    `);
    await runAsync(`CREATE INDEX IF NOT EXISTS idx_ts5m_pump ON time_series_5m(bucket_start, pump_count)`);

    // 2) pool_totals (single-row)
    await runAsync(`
      CREATE TABLE IF NOT EXISTS pool_totals (
        id             INTEGER PRIMARY KEY CHECK (id = 1),
        pump_total     INTEGER NOT NULL DEFAULT 0,
        first_event_ts TEXT    NULL,
        last_updated   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%f', 'now'))
      )
    `);

    // Ensure single row exists
    await runAsync(
      `INSERT OR IGNORE INTO pool_totals (id, last_updated) VALUES (1, ?)`,
      [nowUtcString()]
    );

    // 3) baseline_tracker with archived roll-up fields present from the start
    await runAsync(`
      CREATE TABLE IF NOT EXISTS baseline_tracker (
        id                   INTEGER PRIMARY KEY CHECK (id = 1),
        cum_cat_count        INTEGER NOT NULL DEFAULT 0,
        cum_dog_count        INTEGER NOT NULL DEFAULT 0,
        cum_other_count      INTEGER NOT NULL DEFAULT 0,
        cum_active_hours     REAL    NOT NULL DEFAULT 0,
        last_cat_rate        REAL    NOT NULL DEFAULT 0,
        last_dog_rate        REAL    NOT NULL DEFAULT 0,
        last_other_rate      REAL    NOT NULL DEFAULT 0,
        archived_cat_count   INTEGER NOT NULL DEFAULT 0,
        archived_dog_count   INTEGER NOT NULL DEFAULT 0,
        archived_other_count INTEGER NOT NULL DEFAULT 0,
        archived_active_hours REAL   NOT NULL DEFAULT 0,
        rollup_through_ts    TEXT    NOT NULL DEFAULT '1970-01-01 00:00:00',
        last_updated         TEXT    NOT NULL
      )
    `);

    const farPastDate = '1970-01-01 00:00:00';
    await runAsync(
      `INSERT OR IGNORE INTO baseline_tracker (id, last_updated) VALUES (1, ?)`,
      [farPastDate]
    );

    // 4) server_heartbeat
    await runAsync(`
      CREATE TABLE IF NOT EXISTS server_heartbeat (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT    NOT NULL
      )
    `);

    // 5) server_sessions
    await runAsync(`
      CREATE TABLE IF NOT EXISTS server_sessions (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        start_ts  TEXT    NOT NULL,
        end_ts    TEXT    NULL
      )
    `);
    await runAsync(`CREATE INDEX IF NOT EXISTS idx_sessions_start_end ON server_sessions(start_ts, end_ts)`);

    // 6) forecasts (state + point forecasts) — generated_at required from day‑1
    await runAsync(`
      CREATE TABLE IF NOT EXISTS forecasts (
        forecast_ts TEXT NOT NULL,
        category    TEXT NOT NULL,
        point       REAL NOT NULL,
        lower_ci    REAL NOT NULL,
        upper_ci    REAL NOT NULL,
        level       REAL NOT NULL,
        trend       REAL NOT NULL,
        gamma_param REAL NOT NULL,
        phi         REAL NOT NULL DEFAULT 0.95,		
        seasonal    TEXT NOT NULL,
        generated_at TEXT NOT NULL,
        PRIMARY KEY (forecast_ts, category)
      )
    `);
    await runAsync(`CREATE INDEX IF NOT EXISTS idx_forecasts_category ON forecasts(category)`);

    // 7) residuals (forecast error tracking)
    await runAsync(`
      CREATE TABLE IF NOT EXISTS residuals (
        ts        TEXT    NOT NULL,
        category  TEXT    NOT NULL,
        residual  REAL    NOT NULL
      )
    `);
    await runAsync(`CREATE INDEX IF NOT EXISTS idx_residuals_ts ON residuals(ts)`);
    await runAsync(`CREATE INDEX IF NOT EXISTS idx_residuals_category_ts ON residuals(category, ts)`);

    // 8) Immutable daily season forecast table
    await runAsync(`
      CREATE TABLE IF NOT EXISTS season_forecast_daily (
        date_utc           TEXT    PRIMARY KEY,
        forecast_ts_start  TEXT    NOT NULL,
        season             TEXT    NOT NULL,
        intensity_pct      REAL    NOT NULL,
        sums_cat           REAL    NOT NULL,
        sums_dog           REAL    NOT NULL,
        sums_other         REAL    NOT NULL,
        expected_cat       REAL    NOT NULL,
        expected_dog       REAL    NOT NULL,
        expected_other     REAL    NOT NULL,
        delta_cat          REAL    NOT NULL,
        delta_dog          REAL    NOT NULL,
        delta_other        REAL    NOT NULL,
        z_cat              REAL    NOT NULL,
        z_dog              REAL    NOT NULL,
        z_other            REAL    NOT NULL,
        steps              INTEGER NOT NULL,
        points_cat         TEXT    NOT NULL,
        points_dog         TEXT    NOT NULL,
        points_other       TEXT    NOT NULL,
        created_at         TEXT    NOT NULL
      )
    `);

    // 9) Final index
    await runAsync(`CREATE INDEX IF NOT EXISTS idx_server_heartbeat_ts ON server_heartbeat(timestamp)`);

    return true;
  } catch (err) {
    console.error("Error initializing database:", err);
    throw err;
  }
}

/**
 * getCurrentBucketStart()
 *   Returns a string "YYYY-MM-DD HH:MM:SS" representing the current UTC time
 *   truncated to the nearest 5-minute boundary.
 */
function getCurrentBucketStart() {
  const now = new Date();
  // Truncate to UTC
  const year   = now.getUTCFullYear();
  const month  = now.getUTCMonth();
  const day    = now.getUTCDate();
  const hour   = now.getUTCHours();
  const minute = now.getUTCMinutes();

  // Round down minute to nearest multiple of 5
  const bucketMinute = Math.floor(minute / 5) * 5;

  // Build a new Date object in UTC for the bucket start
  const bucketDate = new Date(Date.UTC(year, month, day, hour, bucketMinute, 0, 0));
  // Format: "YYYY-MM-DD HH:MM:SS"
  const iso = bucketDate.toISOString(); // e.g. "2025-06-01T14:50:00.000Z"
  return iso.slice(0, 19).replace('T', ' '); // → "2025-06-01 14:50:00"
}

/**
 * upsertBucket(bucketStart, catInc, dogInc, otherInc)
 *   Increments the given 5-minute bucket by these amounts.
 *   If no row exists for that bucket_start, inserts a new row.
 */
async function upsertBucket(bucketStart, catInc, dogInc, otherInc, pumpInc = 0) {
  // Sanitize inputs to prevent NaN
  const sanitize = (val) => {
    if (val === null || val === undefined || isNaN(val)) return 0;
    return val;
  };
  
  const sql = `
    INSERT INTO time_series_5m (bucket_start, cat_count, dog_count, other_count, prediction_count, pump_count)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(bucket_start) DO UPDATE SET
      cat_count        = cat_count + excluded.cat_count,
      dog_count        = dog_count + excluded.dog_count,
      other_count      = other_count + excluded.other_count,
      prediction_count = prediction_count + excluded.prediction_count,
      pump_count       = pump_count + excluded.pump_count
  `;
  
  await runAsync(sql, [
    bucketStart,
    sanitize(catInc),
    sanitize(dogInc),
    sanitize(otherInc),
    sanitize(catInc + dogInc + otherInc),
    sanitize(pumpInc)
  ]);
}

/**
 * deleteOldBuckets(retentionHours)
 *   Prune any bucket older than retentionHours.
 *   Uses JS UTC to compute cutoff, not SQLite's datetime().
 */
async function deleteOldBuckets(retentionHours) {
  try {
    // Compute JS-based cutoff string
    const cutoffTime = new Date(Date.now() - retentionHours * 3600_000)
      .toISOString().slice(0, 19).replace('T', ' ');
    await runAsync(`
      DELETE FROM time_series_5m
      WHERE bucket_start < ?
    `, [ cutoffTime ]);
  } catch (err) {
    console.error("Error pruning old buckets:", err);
  }
}

// aiDatabase.js — FINAL calculateLifetimeBaseline() (Option B)
async function calculateLifetimeBaseline() {
  // 1) Read baseline (includes archived fields after migration)
  const row = await getAsync(`
    SELECT
      cum_cat_count, cum_dog_count, cum_other_count, cum_active_hours, last_updated,
      COALESCE(archived_cat_count, 0)    AS arch_cat,
      COALESCE(archived_dog_count, 0)    AS arch_dog,
      COALESCE(archived_other_count, 0)  AS arch_other,
      COALESCE(archived_active_hours, 0) AS arch_hours
    FROM baseline_tracker
    WHERE id = 1
  `);
  if (!row) { console.error("baseline_tracker row missing (id=1)"); return; }

  // 2) Live totals & bounds
  const live = await getAsync(`
    SELECT
      COALESCE(SUM(cat_count), 0)   AS cat,
      COALESCE(SUM(dog_count), 0)   AS dog,
      COALESCE(SUM(other_count), 0) AS other,
      COUNT(*)                      AS totalBuckets,
      MIN(bucket_start)             AS minBucket,
      MAX(bucket_start)             AS maxBucket
    FROM time_series_5m
  `);

  // 3) Lifetime totals = archived + live
  const totalCat   = (row.arch_cat   || 0) + (live.cat   || 0);
  const totalDog   = (row.arch_dog   || 0) + (live.dog   || 0);
  const totalOther = (row.arch_other || 0) + (live.other || 0);

  // 4) Denominator = archived_active_hours + live hours over [min,max)
  let liveHours = 0;
  if (live.totalBuckets > 0) {
    const minB = live.minBucket || '1970-01-01 00:00:00';
    const maxB = live.maxBucket || nowUtcString();
    liveHours = await getActiveHoursRange(minB, maxB);
  }
  const activeHours = (row.arch_hours || 0) + liveHours;
  if (activeHours <= 0) { console.log("No active hours yet; cannot compute baseline."); return; }

  // 5) Full vs incremental
  const needsFullRecalc =
    row.last_updated === '1970-01-01 00:00:00' ||
    row.cum_cat_count   !== totalCat ||
    row.cum_dog_count   !== totalDog ||
    row.cum_other_count !== totalOther;

  if (needsFullRecalc) {
    const catRate   = totalCat   / activeHours;
    const dogRate   = totalDog   / activeHours;
    const otherRate = totalOther / activeHours;
    const lastUpd = live.totalBuckets > 0 ? (live.maxBucket || nowUtcString()) : nowUtcString();

    await runAsync(`
      UPDATE baseline_tracker
         SET cum_cat_count     = ?,
             cum_dog_count     = ?,
             cum_other_count   = ?,
             cum_active_hours  = ?,
             last_cat_rate     = ?,
             last_dog_rate     = ?,
             last_other_rate   = ?,
             last_updated      = ?
       WHERE id = 1
    `, [ totalCat, totalDog, totalOther, activeHours, catRate, dogRate, otherRate, lastUpd ]);

    lifetimeBaselineCache.catRate    = catRate;
    lifetimeBaselineCache.dogRate    = dogRate;
    lifetimeBaselineCache.otherRate  = otherRate;
    lifetimeBaselineCache.lastUpdate = new Date(lastUpd + "Z");
    return; // important: don’t continue into incremental path
  }

  // Incremental update since last_updated
  const newBuckets = await allAsync(`
    SELECT bucket_start, cat_count, dog_count, other_count
      FROM time_series_5m
     WHERE bucket_start > ?
     ORDER BY bucket_start ASC
  `, [ row.last_updated ]);
  if (newBuckets.length === 0) return;

  const added = newBuckets.reduce((acc, b) => {
    acc.cat += b.cat_count; acc.dog += b.dog_count; acc.other += b.other_count; return acc;
  }, { cat: 0, dog: 0, other: 0 });

  const maxBucketStart = newBuckets[newBuckets.length - 1].bucket_start;
  const activeHoursDelta = await getActiveHoursRange(row.last_updated, maxBucketStart);

  const updatedCat   = row.cum_cat_count   + added.cat;
  const updatedDog   = row.cum_dog_count   + added.dog;
  const updatedOther = row.cum_other_count + added.other;
  const updatedHours = row.cum_active_hours + activeHoursDelta;
  if (updatedHours <= 0) return;

  const newCatRate   = updatedCat   / updatedHours;
  const newDogRate   = updatedDog   / updatedHours;
  const newOtherRate = updatedOther / updatedHours;

  await runAsync(`
    UPDATE baseline_tracker
       SET cum_cat_count     = ?,
           cum_dog_count     = ?,
           cum_other_count   = ?,
           cum_active_hours  = ?,
           last_cat_rate     = ?,
           last_dog_rate     = ?,
           last_other_rate   = ?,
           last_updated      = ?
     WHERE id = 1
  `, [ updatedCat, updatedDog, updatedOther, updatedHours,
       newCatRate, newDogRate, newOtherRate, maxBucketStart ]);

  lifetimeBaselineCache.catRate    = newCatRate;
  lifetimeBaselineCache.dogRate    = newDogRate;
  lifetimeBaselineCache.otherRate  = newOtherRate;
  lifetimeBaselineCache.lastUpdate = new Date(maxBucketStart + "Z");
}

/**
 * getAggregatedStatsForAllWindows()
 *   FIXED: Now uses complete buckets only, anchored to getCurrentBucketStart()
 */
async function getAggregatedStatsForAllWindows() {
  const windows = {
    "5m":   5/60,  "15m": 15/60,  "1h": 1,
    "4h":   4,     "8h":  8,      "12h": 12,
    "24h":  24,    "48h": 48,     "72h": 72,
    "1w":   168,   "2w":  336,    "3w": 504,  "1mo": 720
  };
  const endTs = getCurrentBucketStart();

  const result = {};
  for (let [label, hours] of Object.entries(windows)) {
    // 1) Compute window start
    const windowStart = new Date(Date.parse(endTs.replace(' ', 'T') + 'Z') - hours * 3600_000)
      .toISOString().slice(0,19).replace('T',' ');

    // 2) Actual counts via time_series_5m filter - using complete buckets only
    const actualRow = await getAsync(`
      SELECT
        COALESCE(SUM(cat_count),0)   AS cat,
        COALESCE(SUM(dog_count),0)   AS dog,
        COALESCE(SUM(other_count),0) AS other
      FROM time_series_5m
      WHERE bucket_start >= ? AND bucket_start < ?`,
      [windowStart, endTs]
    );
    const actualCat   = actualRow.cat,
          actualDog   = actualRow.dog,
          actualOther = actualRow.other;

    // 3) Active hours from sessions using the fixed function
    const activeHours = await getActiveHoursRange(windowStart, endTs);

    // 4) Expected = baseline_rate × activeHours
    const { catRate, dogRate, otherRate } = lifetimeBaselineCache;
    const expectedCat   = catRate   * activeHours;
    const expectedDog   = dogRate   * activeHours;
    const expectedOther = otherRate * activeHours;

    result[label] = {
      actual:   { cat: actualCat,   dog: actualDog,   other: actualOther },
      expected: { cat: expectedCat, dog: expectedDog, other: expectedOther }
    };
  }
  return result;
}

const TREND_THRESHOLD_UPPER = 1.1;
const TREND_THRESHOLD_LOWER = 0.9;

/**
 * checkForSeasonalShift(windowLabel)
 *   FIXED: Now uses complete buckets only, anchored to getCurrentBucketStart()
 */
async function checkForSeasonalShift(windowLabel) {
  // 1) Determine window bounds
  const hours = {
    "5m":5/60, "15m":15/60, "1h":1,
    "4h":4, "8h":8, "12h":12,
    "24h":24, "48h":48, "72h":72,
    "1w":168, "2w":336, "3w":504, "1mo":720
  }[windowLabel] || 1;
  const endTs = getCurrentBucketStart();
  const windowStart = new Date(Date.parse(endTs.replace(' ', 'T') + 'Z') - hours * 3600_000)
    .toISOString().slice(0,19).replace('T',' ');

  // 2) Actual counts in time_series_5m - using complete buckets only
  const row = await getAsync(`
    SELECT
      COALESCE(SUM(cat_count),0) AS cat,
      COALESCE(SUM(dog_count),0) AS dog
    FROM time_series_5m
    WHERE bucket_start >= ? AND bucket_start < ?`,
    [ windowStart, endTs ]
  );
  const actualCat = row.cat, actualDog = row.dog;

  // 3) Expected via session-driven active hours using the fixed function
  const activeHours = await getActiveHoursRange(windowStart, endTs);
  const { catRate, dogRate } = lifetimeBaselineCache;
  const expectedCat = catRate * activeHours;
  const expectedDog = dogRate * activeHours;

  // 4) Compare
  return {
    cat: compareTrend(actualCat, expectedCat),
    dog: compareTrend(actualDog, expectedDog)
  };
}

function compareTrend(actualVal, expectedVal) {
  if (expectedVal <= 0) return "Stable 🔄";
  const ratio = actualVal / expectedVal;
  if (ratio >= TREND_THRESHOLD_UPPER) return "Trending Up 🚀";
  else if (ratio <= TREND_THRESHOLD_LOWER) return "Trending Down 📉";
  return "Stable 🔄";
}

/**
 * getLifetimeBaseline()
 *   Returns the in-memory cache: {catRate, dogRate, otherRate, lastUpdate}
 */
function getLifetimeBaseline() {
  return { ...lifetimeBaselineCache };
}

/**
 * getLastHourCounts()
 *   FIXED: Now uses complete buckets anchored to getCurrentBucketStart()
 */
async function getLastHourCounts() {
  // Use only COMPLETE buckets: [end-1h, end), where end is the start of the current 5-min bucket
  const endTs = getCurrentBucketStart();
  const startTs = new Date(Date.parse(endTs.replace(' ', 'T') + 'Z') - 3600_000)
    .toISOString().slice(0, 19).replace('T', ' ');
  const row = await getAsync(`
    SELECT
      COALESCE(SUM(cat_count), 0)   AS catCount,
      COALESCE(SUM(dog_count), 0)   AS dogCount,
      COALESCE(SUM(other_count), 0) AS otherCount
    FROM time_series_5m
    WHERE bucket_start >= ? AND bucket_start < ?
  `, [startTs, endTs]);
  return {
    catCount:   row ? row.catCount   : 0,
    dogCount:   row ? row.dogCount   : 0,
    otherCount: row ? row.otherCount : 0
  };
}

/**
 * runMaintenanceTasks()
 * - VACUUM, ANALYZE (outside transactions)
 * - Carry-forward (archive) all 5m rows older than 30 days into baseline_tracker
 * - Then prune time_series_5m, heartbeat, ended sessions, and residuals
 * - All roll-up + prune steps are atomic (BEGIN IMMEDIATE ... COMMIT)
 */
// aiDatabase.js — FINAL runMaintenanceTasks()  (Node 18+)
async function runMaintenanceTasks() {
  try {
    console.log("Running VACUUM…");
    await runAsync("VACUUM");              // keep VACUUM outside transactions
    console.log("VACUUM completed.");

    console.log("Running ANALYZE…");
    await runAsync("ANALYZE");
    console.log("ANALYZE completed.");

    // Retain 30 days = 720 hours
    const retentionHours = 30 * 24;
    const cutoffTime = new Date(Date.now() - retentionHours * 3600_000)
      .toISOString().slice(0, 19).replace('T', ' ');

    // ======== BEGIN ROLL-UP + PRUNE (atomic) ========
    await runAsync('BEGIN IMMEDIATE');

    // 1) Sums to be pruned
    const olderSums = await getAsync(`
      SELECT
        COALESCE(SUM(cat_count), 0)   AS cat,
        COALESCE(SUM(dog_count), 0)   AS dog,
        COALESCE(SUM(other_count), 0) AS other,
        MIN(bucket_start)             AS min_ts
      FROM time_series_5m
      WHERE bucket_start < ?`,
      [cutoffTime]
    );

    const totalPruned = (olderSums?.cat || 0) + (olderSums?.dog || 0) + (olderSums?.other || 0);

    if (totalPruned > 0) {
      // 2) Active hours in [min_ts, cutoffTime)
      const start = olderSums.min_ts || cutoffTime;
      const hours = await getActiveHoursRange(start, cutoffTime);

      // 3) Carry-forward into baseline_tracker
      await runAsync(`
        UPDATE baseline_tracker
           SET archived_cat_count    = archived_cat_count    + ?,
               archived_dog_count    = archived_dog_count    + ?,
               archived_other_count  = archived_other_count  + ?,
               archived_active_hours = archived_active_hours + ?,
               rollup_through_ts     = ?
         WHERE id = 1`,
        [olderSums.cat, olderSums.dog, olderSums.other, hours, cutoffTime]
      );
    }

    // 4) Delete pruned rows
    await runAsync(`DELETE FROM time_series_5m WHERE bucket_start < ?`, [cutoffTime]);

    // 5) Prune other short‑retention tables (no carry‑forward needed)
    await runAsync(`DELETE FROM server_heartbeat WHERE timestamp < ?`, [cutoffTime]);
    await runAsync(`
      DELETE FROM server_sessions
      WHERE end_ts IS NOT NULL AND end_ts < ?`, [cutoffTime]
    );
    await runAsync(`DELETE FROM residuals WHERE ts < ?`, [cutoffTime]);

    await runAsync('COMMIT');
    console.log("Roll-up + pruning completed.");
    // ======== END ROLL-UP + PRUNE ========

  } catch (err) {
    try { await runAsync('ROLLBACK'); } catch {}
    console.error("Error during maintenance tasks:", err);
    throw err;
  }
}

/**
 * close()
 *   Closes the SQLite DB connection, allowing WAL and SHM files to be cleaned up.
 */
async function close() {
  return new Promise((resolve, reject) => {
    db.close(err => (err ? reject(err) : resolve()));
  });
}

// =====================================================================
// NEW HOLT-WINTERS FORECASTING FUNCTIONS
// =====================================================================

/**
 * getHourlySeries(category, hoursBack)
 *   Aggregates 5-minute buckets into complete hourly sums for a given category.
 *   Returns array of {hour_start, count} ordered by hour_start ASC.
 */
async function getHourlySeries(category, hoursBack = 168) {
  // Only use complete hours (ignore current partial hour)
  const now = new Date();
  const currentHour = new Date(Date.UTC(
    now.getUTCFullYear(),
    now.getUTCMonth(),
    now.getUTCDate(),
    now.getUTCHours(),
    0, 0, 0
  ));
  const endTime = currentHour.toISOString().slice(0, 19).replace('T', ' ');
  const startTime = new Date(currentHour.getTime() - hoursBack * 3600_000)
    .toISOString().slice(0, 19).replace('T', ' ');

  const columnName = category + '_count';

  // Aggregate what exists…
  const sql = `
    SELECT 
      strftime('%Y-%m-%d %H:00:00', bucket_start) as hour_start,
      SUM(${columnName}) as count
    FROM time_series_5m
    WHERE bucket_start >= ? AND bucket_start < ?
    GROUP BY hour_start
    ORDER BY hour_start ASC
  `;
  const rows = await allAsync(sql, [startTime, endTime]);

  // …then zero-fill any fully missing hours to produce a regular hourly grid.
  // This ensures Holt–Winters learns that "when the server is off, counts are zero."
  const map = new Map(rows.map(r => [r.hour_start, Number(r.count) || 0]));
  const series = [];
  let t = new Date(startTime.replace(' ', 'T') + 'Z');
  const end = new Date(endTime.replace(' ', 'T') + 'Z');
  while (t < end) {
    const key = t.toISOString().slice(0, 19).replace('T', ' ');
    series.push({ hour_start: key, count: map.get(key) ?? 0 });
    t = new Date(t.getTime() + 3600_000);
  }
  return series;
}

/**
 * getAllForecastsSince(sinceTimestamp)
 *   Returns all forecasts with forecast_ts >= sinceTimestamp
 */
async function getAllForecastsSince(sinceTimestamp) {
  const sql = `
    SELECT 
      forecast_ts,
      category,
      point,
      lower_ci,
      upper_ci
    FROM forecasts
    WHERE forecast_ts >= ?
    ORDER BY forecast_ts ASC, category ASC
  `;
  
  const rows = await allAsync(sql, [sinceTimestamp]);
  return rows;
}

/**
 * insertResidual(ts, category, residual)
 *   Records a forecast error (residual) for later analysis
 */
async function insertResidual(ts, category, residual) {
  await runAsync(
    `INSERT INTO residuals (ts, category, residual) VALUES (?, ?, ?)`,
    [ts, category, residual]
  );
}

/**
 * fetchResiduals(category, sinceTs)
 *   Returns residuals for a category since a given timestamp
 */
async function fetchResiduals(category, sinceTs) {
  return allAsync(
    `SELECT residual FROM residuals WHERE category = ? AND ts >= ?`,
    [category, sinceTs]
  );
}

/**
 * getActualHourlyCount(category, hourStart)
 *   Get the actual hourly count for a specific hour
 */
async function getActualHourlyCount(category, hourStart) {
  const columnName = category + '_count';
  
  // Robust timestamp parsing
  const startDt = new Date(hourStart.replace(' ', 'T') + 'Z');
  const endDt = new Date(startDt.getTime() + 3600_000);
  const startTs = startDt.toISOString().slice(0, 19).replace('T', ' ');
  const endTs = endDt.toISOString().slice(0, 19).replace('T', ' ');
  
  const sql = `
    SELECT COALESCE(SUM(${columnName}), 0) as count
    FROM time_series_5m
    WHERE bucket_start >= ? AND bucket_start < ?
  `;
  
  const row = await getAsync(sql, [startTs, endTs]);
  return row ? row.count : 0;
}

/**
 * insertSeasonForecastDaily(dayUtc, payload)
 *  Immutable insert: if today's row exists, ignore.
 */
async function insertSeasonForecastDaily(dayUtc, payload) {
  const {
    forecast_ts_start, season, intensityPct, sums, expected, delta, zScores, steps, points
  } = payload;
  const sql = `
    INSERT OR IGNORE INTO season_forecast_daily (
      date_utc, forecast_ts_start, season, intensity_pct,
      sums_cat, sums_dog, sums_other,
      expected_cat, expected_dog, expected_other,
      delta_cat, delta_dog, delta_other,
      z_cat, z_dog, z_other,
      steps, points_cat, points_dog, points_other, created_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  const createdAt = nowUtcString();
  const res = await runAsync(sql, [
    dayUtc, forecast_ts_start, season, intensityPct,
    sums.cat, sums.dog, sums.other,
    expected.cat, expected.dog, expected.other,
    delta.cat, delta.dog, delta.other,
    zScores.cat, zScores.dog, zScores.other,
    steps,
    JSON.stringify(points.cat), JSON.stringify(points.dog), JSON.stringify(points.other),
    createdAt
  ]);
  return res.changes === 1; // true if inserted, false if already present
}

async function getSeasonForecastDaily(dayUtc) {
  return getAsync(`SELECT * FROM season_forecast_daily WHERE date_utc = ?`, [dayUtc]);
}

async function getLatestSeasonForecastDaily() {
  return getAsync(`SELECT * FROM season_forecast_daily ORDER BY date_utc DESC LIMIT 1`, []);
}

/**
 * upsertForecast(forecastData)
 *   Inserts or updates a forecast row in the forecasts table.
 *   Note: we store Holt-Winters state.level → alpha, state.trend → beta, state.gamma → gamma
 */
async function upsertForecast(forecastData) {
  const {
    forecast_ts,
    category,
    point,
    lower_ci,
    upper_ci,
    level, trend, gamma_param, phi, seasonal,
	generated_at
  } = forecastData;

  const sql = `
    INSERT INTO forecasts (
      forecast_ts, category, point, lower_ci, upper_ci,
      level, trend, gamma_param, phi, seasonal, generated_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(forecast_ts, category) DO UPDATE SET
      point       = excluded.point,
      lower_ci    = excluded.lower_ci,
      upper_ci    = excluded.upper_ci,
      level       = excluded.level,
      trend       = excluded.trend,
      gamma_param = excluded.gamma_param,
      phi         = excluded.phi,
      seasonal    = excluded.seasonal,
	  generated_at= excluded.generated_at
  `;

  await runAsync(sql, [
    forecast_ts,
    category,
    point,
    lower_ci,
    upper_ci,
    level,
    trend,
    gamma_param,
    phi,
    JSON.stringify(seasonal),
	generated_at
  ]);
}

/**
 * Additive Holt-Winters with proper damped trend (Gardner & McKenzie)
 */
class SimpleHoltWinters {
  constructor(data, period = 24, alpha = 0.3, beta = 0.1, gamma = 0.3, phi = 0.95) {
    this.data = data;
    this.period = period;
    this.alpha = alpha;
    this.beta = beta;
    this.gamma = gamma;
    // Damped-trend factor: phi in (0,1], default 0.95
    this.phi = phi;
    
    // Initialize components
    this.level = 0;
    this.trend = 0;
    this.seasonal = new Array(period).fill(0);
    
    if (data.length >= 2 * period) {
      this._initialize();
    }
  }

  _initialize() {
    // Initial level: average of first season
    this.level = this.data.slice(0, this.period).reduce((a, b) => a + b, 0) / this.period;
    
    // Initial trend: average difference between corresponding periods
    let trendSum = 0;
    for (let i = 0; i < this.period; i++) {
      trendSum += (this.data[i + this.period] - this.data[i]) / this.period;
    }
    this.trend = trendSum / this.period;
    
    // Initial seasonal indices
    for (let i = 0; i < this.period; i++) {
      let seasonSum = 0;
      let count = 0;
      for (let j = i; j < this.data.length; j += this.period) {
        seasonSum += this.data[j] - (this.level + this.trend * Math.floor(j / this.period));
        count++;
      }
      this.seasonal[i] = seasonSum / count;
    }
  }

  update(newValue) {
    const seasonalIdx = this.data.length % this.period;
    const oldLevel = this.level;
    const oldTrend = this.trend;
    const oldSeasonal = this.seasonal[seasonalIdx];
    
    // Update level (with damped trend in the carry-forward)
    this.level = this.alpha * (newValue - oldSeasonal) + 
                 (1 - this.alpha) * (oldLevel + this.phi * oldTrend);
    
    // Update trend (with damping)
    this.trend = this.beta * (this.level - oldLevel) + 
                 (1 - this.beta) * this.phi * oldTrend;
    
    // Update seasonal
    this.seasonal[seasonalIdx] = this.gamma * (newValue - this.level) + (1 - this.gamma) * oldSeasonal;
    
    this.data.push(newValue);
  }

  forecast(steps = 1) {
    const forecasts = [];
    for (let i = 0; i < steps; i++) {
      const seasonalIdx = (this.data.length + i) % this.period;
      // Damped trend: cumulative damping over h steps
      const h = i + 1;
      const trendComponent = (Math.abs(1 - this.phi) < 1e-12)
        ? this.trend * h
        : this.trend * (1 - Math.pow(this.phi, h)) / (1 - this.phi);
      const forecast = this.level + trendComponent + this.seasonal[seasonalIdx];
      forecasts.push(Math.max(0, forecast)); // Ensure non-negative
    }
    return forecasts;
  }

  getState() {
    return {
      level: this.level,
      trend: this.trend,
      seasonal: [...this.seasonal],
      alpha: this.alpha,
      beta: this.beta,
      gamma: this.gamma,
      phi: this.phi
    };
  }

  setState(state) {
    this.level = state.level;
    this.trend = state.trend;
    this.seasonal = [...state.seasonal];
    this.alpha = state.alpha;
    this.beta = state.beta;
    this.gamma = state.gamma;
    this.phi = (state.phi ?? this.phi);
  }
}

/**
 * Quantile functions for count distributions
 */
function qpois(p, mu) { // Poisson quantile
  const maxK = Math.max(10, Math.ceil(mu + 10 * Math.sqrt(mu + 1)));
  let lo = 0, hi = maxK;
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    if (poissonCDF(mid, mu) >= p) hi = mid; else lo = mid + 1;
  }
  return lo;
}

function poissonCDF(k, mu) { // Poisson CDF
  let sum = Math.exp(-mu), term = sum;
  for (let i = 1; i <= k; i++) { 
    term *= mu / i; 
    sum += term; 
  }
  return Math.min(sum, 1);
}

function qnbinom(p, mu, k) { // Negative Binomial quantile
  const prob = k / (k + mu);
  const maxK = Math.max(10, Math.ceil(mu + 10 * Math.sqrt(mu + mu*mu/k)));
  let lo = 0, hi = maxK;
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    if (nbinomCDF(mid, k, prob) >= p) hi = mid; else lo = mid + 1;
  }
  return lo;
}

function nbinomCDF(x, r, p) { // Negative Binomial CDF
  let sum = Math.pow(p, r), term = sum;
  for (let k = 1; k <= x; k++) { 
    term *= (1 - p) * (r + k - 1) / k; 
    sum += term; 
  }
  return Math.min(sum, 1);
}

/**
 * computeHoltWinters(category, period)
 *   Main function to compute Holt-Winters forecast for a category.
 *   - Loads hourly time series data
 *   - Checks for existing forecast state
 *   - Performs incremental update or full fit
 *   - Saves forecast and state to database
 *   - Uses residuals to compute confidence intervals
 */
async function computeHoltWinters(category, period = 24) {
  try {
    // Get hourly series (we need at least 2 periods for initialization)
    const minHours = period * 2 + 1;
    const hourlyData = await getHourlySeries(category, Math.max(168, minHours));
    
    if (hourlyData.length < minHours) {
      console.log(`Not enough data for ${category} forecast (need ${minHours} hours, have ${hourlyData.length})`);
      return null;
    }

    // Extract just the counts
    const values = hourlyData.map(h => h.count);
    
    // Get the next hour timestamp
    const lastHour = new Date(hourlyData[hourlyData.length - 1].hour_start.replace(' ', 'T') + 'Z');
    const nextHour = new Date(lastHour.getTime() + 3600_000);
    const forecastTs = nextHour.toISOString().slice(0, 19).replace('T', ' ');

    // Check for existing forecast state from previous hour
    const prevHour = new Date(lastHour.getTime() - 3600_000);
    const prevForecastTs = lastHour.toISOString().slice(0, 19).replace('T', ' ');
    
    const existingForecast = await getAsync(
      `SELECT * FROM forecasts WHERE forecast_ts = ? AND category = ?`,
      [prevForecastTs, category]
    );

    let hw;
    if (existingForecast) {
      // Load state and do incremental update
      console.log(`Loading existing HW state for ${category}`);
	  hw = new SimpleHoltWinters(values.slice(0, -1), period);
	  hw.setState({
		level: existingForecast.level,
		trend: existingForecast.trend,
		seasonal: JSON.parse(existingForecast.seasonal),
		alpha: 0.3,
		beta: 0.1,
		gamma: existingForecast.gamma_param ?? 0.3,
		phi:   existingForecast.phi ?? 0.95
	  });
      
      // Update with the latest value
      hw.update(values[values.length - 1]);
    } else {
      // Full fit
      console.log(`Performing full HW fit for ${category}`);
      hw = new SimpleHoltWinters(values, period);
    }

    // Generate forecast
    const [pointForecast] = hw.forecast(1);
    
    // Calculate prediction intervals using count-appropriate distributions
    let lowerCI, upperCI;
    
    // Get dispersion parameter for quasi-Poisson/NB model
    const mu = Math.max(pointForecast, 1e-6);
    const phi = await estimateDispersionForCategory(category, 48);
    
    console.log(`${category}: mu=${mu.toFixed(2)}, phi=${phi.toFixed(2)}`);
    
    if (phi <= 1 + 1e-6) {
      // Poisson prediction interval
      lowerCI = qpois(0.025, mu);
      upperCI = qpois(0.975, mu);
      console.log(`${category}: Using Poisson PI`);
    } else {
      // Negative Binomial prediction interval via moment-matching
      const k = mu / (phi - 1); // size parameter
      lowerCI = qnbinom(0.025, mu, k);
      upperCI = qnbinom(0.975, mu, k);
      console.log(`${category}: Using NB PI (k=${k.toFixed(2)})`);
    }
    
    // Optional: Still track residuals for diagnostics (increase to 28 days)
    const since = new Date(Date.now() - 28 * 24 * 3600_000)
      .toISOString().slice(0, 19).replace('T', ' ');
    const rows = await fetchResiduals(category, since);
    if (rows.length >= 2) {
      const residuals = rows.map(r => r.residual);
      const sigma = Math.sqrt(residuals.reduce((s, e) => s + Math.pow(e - residuals.reduce((a, b) => a + b, 0) / residuals.length, 2), 0) / (residuals.length - 1));
      console.log(`${category}: Historical residual σ=${sigma.toFixed(2)} (for diagnostics only)`);
     } else {
      console.log(`${category}: Insufficient residual history (${rows.length} samples)`);
     }
    
    // Get current state
    const state = hw.getState();
    
    // Save to database
	const genAt = new Date().toISOString().slice(0,19).replace('T',' ');
	await upsertForecast({
		  forecast_ts: forecastTs,
		  category: category,
		  point: pointForecast,
		  lower_ci: lowerCI,
		  upper_ci: upperCI,
		  level: state.level,
		  trend: state.trend,
		  gamma_param: state.gamma,
		  phi: state.phi,
		  seasonal: state.seasonal,
		  generated_at: genAt
		});

    console.log(`${category} forecast for ${forecastTs}: ${pointForecast.toFixed(2)} [${lowerCI.toFixed(2)}, ${upperCI.toFixed(2)}]`);
    
    return {
      category,
      forecast_ts: forecastTs,
      point: pointForecast,
      lower_ci: lowerCI,
      upper_ci: upperCI,
	  generated_at: genAt
    };
  } catch (err) {
    console.error(`Error computing Holt-Winters for ${category}:`, err);
    return null;
  }
}

/**
 * computeHoltWintersMulti(category, steps, period)
 *  - Builds/updates HW state exactly like computeHoltWinters()
 *  - Returns multi‑step point forecasts WITHOUT persisting rows
 *  - Used by the Season forecast (next 24 h)
 */
async function computeHoltWintersMulti(category, steps = 24, period = 24) {
  try {
    const minHours = period * 2 + 1;
    const hourlyData = await getHourlySeries(category, Math.max(168, minHours));
    if (hourlyData.length < minHours) {
      console.log(`Not enough data for ${category} multi‑step forecast (need ${minHours}, have ${hourlyData.length})`);
      return null;
    }

    const values = hourlyData.map(h => h.count);
    const lastHour = new Date(hourlyData[hourlyData.length - 1].hour_start.replace(' ', 'T') + 'Z');
    const nextHour = new Date(lastHour.getTime() + 3600_000);
    const forecastTsStart = nextHour.toISOString().slice(0, 19).replace('T', ' ');

    const prevHour = new Date(lastHour.getTime() - 3600_000);
    const prevForecastTs = lastHour.toISOString().slice(0, 19).replace('T', ' ');
    const existingForecast = await getAsync(
      `SELECT * FROM forecasts WHERE forecast_ts = ? AND category = ?`,
      [prevForecastTs, category]
    );

    let hw;
    if (existingForecast) {
      // Use persisted state and update with the latest actual
      hw = new SimpleHoltWinters(values.slice(0, -1), period);
	  hw.setState({
		level:     existingForecast.level,
		trend:     existingForecast.trend,
		seasonal:  JSON.parse(existingForecast.seasonal),
		alpha: 0.3, beta: 0.1,
		gamma: existingForecast.gamma_param ?? 0.3,
		phi:   existingForecast.phi ?? 0.95
	  });
      hw.update(values[values.length - 1]);
    } else {
      // Fall back to a full fit
      hw = new SimpleHoltWinters(values, period);
    }

    const points = hw.forecast(steps);
    const sum = points.reduce((a, b) => a + b, 0);
    return { category, forecast_ts_start: forecastTsStart, points, sum };
  } catch (err) {
    console.error(`Error computing multi‑step Holt‑Winters for ${category}:`, err);
    return null;
  }
}

// Update incrementPoolTotal function - now only for pump tracking
async function incrementPoolTotal(inc = 1) {
  await runAsync(`
    UPDATE pool_totals
    SET pump_total = pump_total + ?,
        last_updated = ?,
        first_event_ts = CASE WHEN pump_total = 0 THEN ? ELSE first_event_ts END
    WHERE id = 1
  `, [inc, nowUtcString(), nowUtcString()]);
}

/**
 * Returns counts, baseline rates and timestamp.
 * Baseline = lifetime share since first count in pool_totals.
 */
async function getPoolSnapshot() {
  const row = await getAsync(`
    SELECT pump_total, last_updated, first_event_ts 
    FROM pool_totals 
    WHERE id = 1
  `) || {};
  
  const total = row.pump_total || 0;
  
  return {
    count: total,
    lastUpdated: row.last_updated || null,
    firstEventTs: row.first_event_ts || null
  };
}

/**
 * Estimate quasi-Poisson dispersion (Pearson) per category from the last N hours.
 * Uses hourly aggregates and session-aware expected counts per hour.
 * Moved from aiServer.js for reuse in computeHoltWinters()
 */
async function estimateDispersion(hoursBack = 48) {
  const { catRate, dogRate, otherRate } = getLifetimeBaseline();
  const rate = { cat: catRate, dog: dogRate, other: otherRate };
  const phi = {};

  for (const k of ['cat', 'dog', 'other']) {
    const series = await getHourlySeries(k, hoursBack); // [{hour_start, count}]
    let chi = 0, n = 0;
    for (const row of series) {
      const start = row.hour_start; // "YYYY-MM-DD HH:00:00" (UTC-aligned)
      const end = new Date(new Date(start.replace(' ', 'T') + 'Z').getTime() + 3600_000)
        .toISOString().slice(0, 19).replace('T', ' ');
      const hrs = await getActiveHoursRange(start, end);
      if (hrs <= 0) continue;
      const mu = Math.max(rate[k] * hrs, 1e-6);
      chi += Math.pow(row.count - mu, 2) / mu;
      n++;
    }
    phi[k] = n > 1 ? Math.max(chi / (n - 1), 1) : 1; // clamp at Poisson lower bound
  }
  return phi;
}

async function estimateDispersionForCategory(category, hoursBack = 48) {
  const allPhi = await estimateDispersion(hoursBack);
  return allPhi[category] || 1;
}

async function getLastHeartbeatTs() {
  const row = await getAsync(`SELECT MAX(timestamp) AS ts FROM server_heartbeat`);
  return row && row.ts ? row.ts : null;
}

module.exports = {
  initializeDatabase,
  upsertBucket,
  calculateLifetimeBaseline,
  getAggregatedStatsForAllWindows,
  checkForSeasonalShift,
  getLastHourCounts,
  getLifetimeBaseline,
  runMaintenanceTasks,
  lifetimeBaselineCache,
  getAsync,
  runAsync,
  getCurrentBucketStart,
  getActiveHours,
  getActiveHoursRange, 
  nowUtcString,
  close,
  getHourlySeries,
  upsertForecast,
  computeHoltWinters,
  computeHoltWintersMulti,
  getAllForecastsSince,
  insertResidual,
  fetchResiduals,
  getActualHourlyCount,
  insertSeasonForecastDaily,
  getSeasonForecastDaily,
  getLatestSeasonForecastDaily,
  incrementPoolTotal,
  getPoolSnapshot,
  estimateDispersion,
  estimateDispersionForCategory,
  getLastHeartbeatTs
};