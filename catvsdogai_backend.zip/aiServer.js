// aiServer.js
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const fs = require('fs').promises;

const TOKEN_IMAGES_DIR = process.env.TOKEN_IMAGES_DIR || '/var/www/backend/token_images';
const SAFE_IMAGE_MAX_AGE_MINUTES = Number(process.env.SAFE_IMAGE_MAX_AGE_MINUTES || 600); // 10h safety window

const {
  initializeDatabase,
  upsertBucket,
  calculateLifetimeBaseline,
  getAggregatedStatsForAllWindows,
  checkForSeasonalShift,
  getLastHourCounts,
  getLifetimeBaseline,
  runMaintenanceTasks,
  runAsync,
  getAsync,
  getCurrentBucketStart,
  getActiveHours,
  getActiveHoursRange,  
  nowUtcString,
  close,
  computeHoltWinters,
  computeHoltWintersMulti,
  getAllForecastsSince,
  insertResidual,
  fetchResiduals,
  getActualHourlyCount,
  getHourlySeries,
  insertSeasonForecastDaily,
  getSeasonForecastDaily,
  getLatestSeasonForecastDaily,
  incrementPoolTotal,
  getPoolSnapshot,
  estimateDispersion,
  estimateDispersionForCategory,
  getLastHeartbeatTs 
} = require('./aiDatabase'); // Now handles 5-minute buckets

const PORT = Number(process.env.PORT) || 3001;
const OTHER_BACKEND_WS_URL = process.env.OTHER_BACKEND_WS_URL || 'ws://127.0.0.1:9000';
const STATS_WS_PORT = Number(process.env.STATS_WS_PORT) || 8766;

const app = express();
const server = http.createServer(app);

app.use(express.static(path.join(__dirname, '../frontend')));

let latestImagePrediction = null;
let latestTokenAddresses = [];

// Cached stats / trending / season (updated once per minute)
let cachedStats = null;
let cachedTrending = null;
let cachedSeason = null;
let lastStatsUpdate = null;

// Cached forecasts for REST endpoint
let cachedForecasts = null;
let cachedForecastsGeneratedAt = null;

// Cached season images
let cachedSeasonImages = {};

// Cached Season forecast (next 24 h)
let cachedSeason24hForecast = null;

// Cached Season forecast (next 24 h, static daily)
let cachedSeason24hForecastStatic = null;
let cachedSeason24hForecastStaticDay = null; // 'YYYY-MM-DD'

// Dispersion cache for z-score season decision (quasi-Poisson)
let cachedPhi = { cat: 1, dog: 1, other: 1 };
let lastPhiMs = 0;

// Session management
let currentSessionId = null;

// Minimum lift threshold for pump.fun season detection, env‑tunable
const PUMP_SEASON_LIFT_THRESHOLD = Number(process.env.PUMP_SEASON_LIFT_THRESHOLD ?? 10); // %
const PUMP_SEASON_MIN_SAMPLES    = Number(process.env.PUMP_SEASON_MIN_SAMPLES ?? 50);

// In-memory "current bucket" counters (for the ongoing 5-minute interval)
let currentBucket = {
  bucketStart: getCurrentBucketStart(), // e.g. "2025-06-01 14:50:00"
  cat: 0,
  dog: 0,
  other: 0,
  pump: 0,
  total: 0
};

// Checkpoint tracking for durability
let lastPersisted = {
  bucketStart: currentBucket.bucketStart,
  cat: 0, dog: 0, other: 0, pump: 0
};

// Calculate pump.fun activity from DB for the last complete 24h window
async function getPoolWindowMetrics() {
  const endTs = getCurrentBucketStart();
  const startTs = new Date(Date.parse(endTs.replace(' ', 'T') + 'Z') - 24 * 3600_000)
    .toISOString().slice(0, 19).replace('T', ' ');
  
  const row = await getAsync(`
    SELECT COALESCE(SUM(pump_count), 0) AS count24h
    FROM time_series_5m
    WHERE bucket_start >= ? AND bucket_start < ?
  `, [startTs, endTs]);
  
  const count24h = (row?.count24h || 0) + (currentBucket.pump || 0);
  const activeHours24h = await getActiveHoursRange(startTs, endTs);
  
  // Add current partial bucket uptime
  const nowTs = nowUtcString();
  const partialHours = await getActiveHoursRange(endTs, nowTs);
  const denom = activeHours24h + partialHours;
  const rate24h = denom > 0 ? count24h / denom : 0;
  
  return { count24h, rate24h };
}

// WebSocket for stats + tokens updates (port 8766)
const statsServer = http.createServer();
const statsWss = new WebSocket.Server({ server: statsServer });
let statsClients = new Set();

// Graceful shutdown: flush current bucket on SIGTERM/SIGINT
async function gracefulShutdown() {
  console.log("Received shutdown signal, flushing current bucket...");
  try {
    await flushBucketIfNeeded();

    if (currentSessionId) {
      await runAsync(
        `UPDATE server_sessions SET end_ts = ? WHERE id = ?`,
        [nowUtcString(), currentSessionId]
      );
      console.log("Closed session", currentSessionId);
    }

    console.log("Checkpointing WAL…");
    await runAsync('PRAGMA wal_checkpoint(FULL);');

    console.log("Closing database connection…");
    await close();
  } catch (e) {
    console.error("Error during shutdown:", e);
  } finally {
	console.log("Closing HTTP servers...");
    server.close(() => console.log('HTTP server closed'));
    statsServer.close(() => console.log('Stats WS server closed'));
    
    // Give servers time to close
    await new Promise(resolve => setTimeout(resolve, 1000));
	
    process.exit(0);
  }
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Helper function to get season image paths
async function getSeasonImagePaths(season, n = 50) {
  const label = season === 'cat' ? 'Cat' : 
                season === 'dog' ? 'Dog' : 
                season === 'other' ? 'Other' : null;
  if (!label) return [];

  const nowMs = Date.now();
  const cutoffMs = SAFE_IMAGE_MAX_AGE_MINUTES * 60 * 1000;
  const re = new RegExp(`_${label}_10000_\\d+\\.png$`, 'i');

  try {
    const entries = await fs.readdir(TOKEN_IMAGES_DIR, { withFileTypes: true });
    const files = entries.filter(e => e.isFile()).map(e => e.name);
    
    const candidates = [];
    for (const name of files) {
      if (!re.test(name)) continue;
      try {
        const st = await fs.stat(path.join(TOKEN_IMAGES_DIR, name));
        if (nowMs - st.mtimeMs <= cutoffMs) candidates.push(name);
      } catch {
        // ignore concurrently deleted files
      }
    }

    if (!candidates.length) return [];

    // Fisher-Yates shuffle
    for (let i = candidates.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
    }
    
    const selected = candidates.slice(0, n);
    return selected.map(nm => `/images/backend/${encodeURIComponent(nm)}`);
  } catch (e) {
    console.error('Failed to get season images:', e);
    return [];
  }
}

async function startApp() {
  try {
    await initializeDatabase();

	const now = nowUtcString();

	// Close any dangling previous sessions at the last heartbeat (or now if none)
	const lastBeat = await getLastHeartbeatTs();
	const endFix = lastBeat && new Date(lastBeat.replace(' ', 'T') + 'Z') < new Date(now.replace(' ', 'T') + 'Z')
	  ? lastBeat
	  : now;

	await runAsync(
	  `UPDATE server_sessions SET end_ts = ? WHERE end_ts IS NULL AND start_ts < ?`,
	  [endFix, now]
	);

	// Open a new session
	const res = await runAsync(
	  `INSERT INTO server_sessions (start_ts) VALUES (?)`,
	  [now]
	);
	
    currentSessionId = res.lastID;
    console.log("Opened new session", currentSessionId);

    // Ensure current 5m bucket exists (or load existing)
    const checkRow = await getAsync(
      `SELECT cat_count, dog_count, other_count, pump_count
         FROM time_series_5m
        WHERE bucket_start = ?`,
      [currentBucket.bucketStart]
    );
    if (!checkRow) {
      await runAsync(
        `INSERT INTO time_series_5m 
           (bucket_start, cat_count, dog_count, other_count, prediction_count, pump_count)
         VALUES (?, 0, 0, 0, 0, 0)`,
        [currentBucket.bucketStart]
      );
      console.log(`Initialized missing bucket ${currentBucket.bucketStart} to zeros`);
    } else {
      currentBucket.cat   = checkRow.cat_count;
      currentBucket.dog   = checkRow.dog_count;
      currentBucket.other = checkRow.other_count;
	  currentBucket.pump  = checkRow.pump_count ?? 0;
      currentBucket.total = checkRow.cat_count + checkRow.dog_count + checkRow.other_count;
      console.log(
        `Loaded existing bucket ${currentBucket.bucketStart}: cat=${currentBucket.cat}, dog=${currentBucket.dog}, other=${currentBucket.other}`
      );
    }

    // Heartbeat
    await insertHeartbeat();
    setInterval(insertHeartbeat, 60_000);

    // Checkpoint persistence every 5 seconds
	setInterval(async () => {
	  try {
		// Handle bucket rotation between checkpoints
		if (lastPersisted.bucketStart !== currentBucket.bucketStart) {
		  lastPersisted = {
			bucketStart: currentBucket.bucketStart,
			cat: 0, 
			dog: 0, 
			other: 0,
			pump: 0  // ADD THIS LINE
		  };
		  await upsertBucket(currentBucket.bucketStart, 0, 0, 0, 0);
		}

		const dc = currentBucket.cat   - lastPersisted.cat;
		const dd = currentBucket.dog   - lastPersisted.dog;
		const do_ = currentBucket.other - lastPersisted.other;
		const dp = currentBucket.pump  - (lastPersisted.pump || 0); // Defensive fallback

		if (dc || dd || do_ || dp) {
		  await upsertBucket(currentBucket.bucketStart, dc, dd, do_, dp);
		  lastPersisted.cat   += dc;
		  lastPersisted.dog   += dd;
		  lastPersisted.other += do_;
		  lastPersisted.pump  = (lastPersisted.pump || 0) + dp; // Defensive update
		}
	  } catch (e) {
		console.error("checkpoint persist failed:", e);
	  }
	}, 5000);

    // >>> IMPORTANT: Roll-up + prune first, then compute baseline <<<
    await runMaintenanceTasks();           // Option B: archive + delete (atomic)
    await calculateLifetimeBaseline();     // sees archived + live, no mismatch

    // Start servers
    server.listen(PORT, () => {
      console.log(`CatvsDog.ai backend server listening on port ${PORT}`);
    });
    statsServer.listen(STATS_WS_PORT, () => {
      console.log(`Stats WS server listening on port ${STATS_WS_PORT}`);
    });

    await updateCachedStats();

    console.log('Bootstrapping initial forecasts…');
    try {
      const results = await Promise.all(
        ['cat', 'dog', 'other'].map(c => computeHoltWinters(c).catch(() => null))
      );
      cachedForecasts = results.filter(Boolean);
      cachedForecastsGeneratedAt = new Date().toISOString();
      console.log('Initial forecasts ready');

      // Also compute initial 24h season forecast
      try { await calculateSeasonForecast24h(); } catch (_) {}
      // Hydrate today's static daily forecast (if it exists) or compute if late
      try { await hydrateOrComputeTodayStaticForecast(); } catch (_) {}

    } catch (e) {
      console.error('Initial forecast bootstrap failed:', e);
    }

    // Per-minute loop: flush bucket, baseline, stats, and hot image list
    (async function tickLoop() {
      while (true) {
        try {
          await flushBucketIfNeeded();
          await calculateLifetimeBaseline();
          await updateCachedStats();

          // Push season images every minute if there's an active season
          if (cachedSeason && ['cat', 'dog', 'other'].includes(cachedSeason.season)) {
            const seasonImages = await getSeasonImagePaths(cachedSeason.season, 50);
            if (seasonImages.length > 0) {
              // Cache for REST endpoint
              cachedSeasonImages[cachedSeason.season] = {
                images: seasonImages,
                timestamp: Date.now()
              };

              // Push via WebSocket
              const msg = JSON.stringify({
                type: 'season-images-update',
                season: cachedSeason.season,
                images: seasonImages,
                timestamp: new Date().toISOString()
              });

              statsClients.forEach(client => {
                if (client.readyState === WebSocket.OPEN) client.send(msg);
              });

              console.log(`Pushed ${seasonImages.length} ${cachedSeason.season} image paths to ${statsClients.size} clients`);
            }
          }
        } catch (err) {
          console.error("Error in per-minute tasks:", err);
        }
        await new Promise(res => setTimeout(res, 60_000));
      }
    })();

    // Hourly forecast loop at hh:02
    (async function forecastLoop() {
      while (true) {
        try {
          const now = new Date();
          const next = Date.UTC(
            now.getUTCFullYear(),
            now.getUTCMonth(),
            now.getUTCDate(),
            now.getUTCHours() + 1,
            2, 0, 0
          );
          const targetTime = next > now.getTime() ? next : next + 3600_000;
          const delay = targetTime - now.getTime();

          console.log(`Waiting ${Math.round(delay / 60000)} minutes until next forecast run at :02`);
          await new Promise(r => setTimeout(r, delay));

          await recordForecastResiduals();

          console.log("Computing Holt-Winters forecasts...");
          const catFc   = await computeHoltWinters('cat');
          const dogFc   = await computeHoltWinters('dog');
          const otherFc = await computeHoltWinters('other');

          const forecasts = [catFc, dogFc, otherFc].filter(Boolean);
          if (forecasts.length > 0) {
            cachedForecasts = forecasts;
            cachedForecastsGeneratedAt = new Date().toISOString();

            const msg = JSON.stringify({
              type: 'forecast-update',
              forecasts,
              timestamp: cachedForecastsGeneratedAt
            });

            statsClients.forEach(client => {
              if (client.readyState === WebSocket.OPEN) client.send(msg);
            });

            console.log("Forecast update broadcast to", statsClients.size, "clients on port", STATS_WS_PORT);
          }

          // Compute & broadcast the Season forecast (next 24 h)
          const sf = await calculateSeasonForecast24h();
          if (sf) {
            const msgSF = JSON.stringify({
              type: 'season-forecast-update',
              forecast: sf,
              timestamp: new Date().toISOString()
            });
            statsClients.forEach(client => {
              if (client.readyState === WebSocket.OPEN) client.send(msgSF);
            });
            console.log("Season 24h forecast broadcast to", statsClients.size, "clients");
          }
        } catch (err) {
          console.error("Error in forecast loop:", err);
          await new Promise(res => setTimeout(res, 5 * 60 * 1000));
        }
      }
    })();

    // Daily static forecast loop at 00:02 UTC
    (async function dailyStaticLoop() {
      while (true) {
        try {
          const delay = msUntilNextUtcTime(0, 2, 0); // 00:02:00
          console.log(`Daily static-forecast: sleeping ${Math.round(delay/60000)} min until 00:02 UTC`);
          await new Promise(r => setTimeout(r, delay));
          await computeAndBroadcastStaticForecastForToday();
        } catch (err) {
          console.error("Error in daily static-forecast loop:", err);
          await new Promise(r => setTimeout(r, 10 * 60 * 1000));
        }
      }
    })();
	
    // Nightly roll-up + prune at 00:05 UTC; then refresh baseline
    (async function maintenanceLoop() {
      while (true) {
        try {
          const delay = msUntilNextUtcTime(0, 5, 0); // next 00:05 UTC
          await new Promise(r => setTimeout(r, delay));
          await runMaintenanceTasks();       // atomic carry-forward + prune
          await calculateLifetimeBaseline(); // refresh baseline after roll-up
        } catch (e) {
          console.error("maintenanceLoop error:", e);
          // back-off if something went wrong
          await new Promise(r => setTimeout(r, 10 * 60 * 1000));
        }
      }
    })();

    connectToOtherBackend();
  } catch (err) {
    console.error("Failed to initialize application:", err);
    process.exit(1);
  }
}

startApp();

/** Utility: millis until next UTC hh:mm:ss */
function msUntilNextUtcTime(hh=0, mm=0, ss=0) {
  const now = new Date();
  const next = Date.UTC(
    now.getUTCFullYear(),
    now.getUTCMonth(),
    now.getUTCDate(),
    hh, mm, ss, 0
  );
  const nowMs = now.getTime();
  const target = (nowMs < next) ? next : next + 24*3600_000;
  return target - nowMs;
}

/**
 * Estimate uptime fractions for each of the next 24 full UTC hours.
 * We approximate P(uptime in hour h) by the average active-hours fraction
 * observed for the same hour-of-day over the last `daysBack` days.
 *
 * Returns: Array<number> of length 24 with values in [0,1]
 *
 * NOTE: This issues up to 24 * daysBack small range queries to getActiveHoursRange.
 * It runs at most once per hour (in forecast loop); optimize if needed.
 */
async function getUptimeFractionsNext24(daysBack = 14) {
  const fracs = [];
  const now = new Date();
  const nextHour = new Date(Date.UTC(
    now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),
    now.getUTCHours() + 1, 0, 0, 0
  ));

  for (let i = 0; i < 24; i++) {
    const start = new Date(nextHour.getTime() + i * 3600_000);
    const end   = new Date(start.getTime() + 3600_000);
    let acc = 0;
    for (let d = 1; d <= daysBack; d++) {
      const s = new Date(start.getTime() - d * 24 * 3600_000).toISOString().slice(0,19).replace('T',' ');
      const e = new Date(end.getTime()   - d * 24 * 3600_000).toISOString().slice(0,19).replace('T',' ');
      // getActiveHoursRange returns [0,1] for a 1-hour window; we average this
      // over the last N days to get a fraction in [0,1]
      // (Imported from aiDatabase)
      acc += await getActiveHoursRange(s, e);
    }
    fracs.push(acc / daysBack);
  }
  return fracs;
}

/** One-off hydration on startup: if after 00:10 UTC and no row, compute now; else try to load existing row */
async function hydrateOrComputeTodayStaticForecast() {
  const day = new Date().toISOString().slice(0,10);
  const row = await getSeasonForecastDaily(day);
  if (row) {
    cachedSeason24hForecastStatic = mapDailyRow(row);
    cachedSeason24hForecastStaticDay = day;
    return;
  }
  // if server started late in the day (≥ 00:10 UTC), compute immediately
  const now = new Date();
  if (now.getUTCHours() > 0 || (now.getUTCHours() === 0 && now.getUTCMinutes() >= 10)) {
    await computeAndBroadcastStaticForecastForToday();
  }
}

/** Compute & persist today's static forecast (immutable), then broadcast */
async function computeAndBroadcastStaticForecastForToday() {
  try {
    const result = await calculateSeasonForecast24hStatic(); // compute only
    if (!result) return;
    const day = new Date().toISOString().slice(0,10);
    const inserted = await insertSeasonForecastDaily(day, {
      forecast_ts_start: result.forecast_ts_start,
      season: result.season,
      intensityPct: result.intensityPct,
      sums: result.sums,
      expected: result.expected,
      delta: result.delta,
      zScores: result.zScores,
      steps: result.steps,
      points: result.points
    });
    // Only update cache/broadcast on first insert for the day
    if (inserted) {
      cachedSeason24hForecastStatic = { ...result, date_utc: day };
      cachedSeason24hForecastStaticDay = day;
      const msg = JSON.stringify({ type: 'season-forecast-static-update', forecast: cachedSeason24hForecastStatic });
      statsClients.forEach(c => { if (c.readyState === WebSocket.OPEN) c.send(msg); });
      console.log("Broadcasted daily static season forecast to", statsClients.size, "clients");
    } else {
      // hydrate cache from DB (in case another instance inserted)
      const row = await getSeasonForecastDaily(day);
      if (row) {
        cachedSeason24hForecastStatic = mapDailyRow(row);
        cachedSeason24hForecastStaticDay = day;
      }
    }
  } catch (err) {
    console.error("computeAndBroadcastStaticForecastForToday failed:", err);
  }
}

/** Map DB row → API shape */
function mapDailyRow(row) {
  return {
    mode: 'static',
    date_utc: row.date_utc,
    forecast_ts_start: row.forecast_ts_start,
    season: row.season,
    intensityPct: row.intensity_pct,
    sums: { cat: row.sums_cat, dog: row.sums_dog, other: row.sums_other },
    expected: { cat: row.expected_cat, dog: row.expected_dog, other: row.expected_other },
    delta: { cat: row.delta_cat, dog: row.delta_dog, other: row.delta_other },
    zScores: { cat: row.z_cat, dog: row.z_dog, other: row.z_other },
    steps: row.steps,
    points: {
      cat: JSON.parse(row.points_cat),
      dog: JSON.parse(row.points_dog),
      other: JSON.parse(row.points_other)
    },
    timestamp: row.created_at
  };
}

/** Heartbeat */
async function insertHeartbeat() {
  const nowUtc = nowUtcString();
  try {
    await runAsync(`INSERT INTO server_heartbeat (timestamp) VALUES (?)`, [nowUtc]);
  } catch (error) {
    console.error("Failed to insert heartbeat:", error);
  }
}

/** 5m bucket flush */
async function flushBucketIfNeeded() {
  const nowBucket = getCurrentBucketStart();
  if (nowBucket === currentBucket.bucketStart) return;

  // 1) Atomic swap BEFORE any await
  const prev = currentBucket;
  currentBucket = {
    bucketStart: nowBucket,
    cat: 0, dog: 0, other: 0, pump: 0, total: 0
  };

  try {
    // 2) Write only the unpersisted remainder for the old bucket
    const dc = prev.cat - lastPersisted.cat;
    const dd = prev.dog - lastPersisted.dog;
    const do_ = prev.other - lastPersisted.other;
    const dp = (Number.isFinite(prev.pump) ? prev.pump : 0) - (Number.isFinite(lastPersisted.pump) ? lastPersisted.pump : 0);
    
    if (dc || dd || do_ || dp) {
      await upsertBucket(prev.bucketStart, dc, dd, do_, dp);
    }
    console.log(`Flushed bucket ${prev.bucketStart}: cat=${prev.cat}, dog=${prev.dog}, other=${prev.other}`);
    
    // Mark the old bucket fully persisted
    lastPersisted = {
      bucketStart: prev.bucketStart,
      cat: prev.cat,
      dog: prev.dog,
      other: prev.other,
      pump: Number.isFinite(prev.pump) ? prev.pump : 0
    };

    // 3) Ensure the new bucket row exists
    await upsertBucket(nowBucket, 0, 0, 0);
  } catch (e) {
    console.error("Error flushing bucket:", e);
    // Do NOT roll back the swap; future increments must stay in the new bucket.
  }
}

/** Forecast residuals capture */
async function recordForecastResiduals() {
  try {
    const now = new Date();
    const previousHour = new Date(Date.UTC(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate(),
      now.getUTCHours() - 1,
      0, 0, 0
    ));
    const previousHourTs = previousHour.toISOString().slice(0, 19).replace('T', ' ');

    const forecastsToCheck = await getAllForecastsSince(previousHourTs);

    for (const forecast of forecastsToCheck) {
      if (forecast.forecast_ts === previousHourTs) {
        const actualCount = await getActualHourlyCount(forecast.category, forecast.forecast_ts);
        const residual = actualCount - forecast.point;
        await insertResidual(forecast.forecast_ts, forecast.category, residual);

        console.log(
          `Recorded residual for ${forecast.category} at ${forecast.forecast_ts}: ` +
          `actual=${actualCount}, forecast=${forecast.point.toFixed(2)}, residual=${residual.toFixed(2)}`
        );
      }
    }
  } catch (err) {
    console.error("Error recording forecast residuals:", err);
  }
}

/** Cached stats refresh */
async function updateCachedStats() {
  try {
    const stats = await getAggregatedStatsForAllWindows();
    cachedStats = stats;

    const trendingResults = {};
    const windows = ["5m", "15m", "1h", "4h", "8h", "12h", "24h", "48h", "72h", "1w", "2w", "3w", "1mo"];
    for (let label of windows) {
      trendingResults[label] = await checkForSeasonalShift(label);
    }
    cachedTrending = trendingResults;

    const seasonResult = await calculateSeason();
    cachedSeason = seasonResult;

    lastStatsUpdate = Date.now();
    console.log("Updated cached stats, trending, & season at", new Date(lastStatsUpdate).toISOString());
  } catch (err) {
    console.error("Error updating cached stats:", err);
  }
}

/** REST: latests */
app.get('/api/latest-tokens', (req, res) => {
  res.json(latestTokenAddresses);
});

app.get('/api/latest', (req, res) => {
  res.json(latestImagePrediction || { message: 'No prediction available yet' });
});

/** REST: stats */
app.get('/api/stats', async (req, res) => {
  if (!cachedStats) return res.status(503).json({ error: 'Stats not yet loaded. Try again shortly.' });

  const perfWindow = cachedStats['24h'];
  const safeDivide = (num, den) => den > 0 ? num / den : 0;
  const performance = {
    cat:   safeDivide(perfWindow.actual.cat,   perfWindow.expected.cat),
    dog:   safeDivide(perfWindow.actual.dog,   perfWindow.expected.dog),
    other: safeDivide(perfWindow.actual.other, perfWindow.expected.other)
  };

  const { catRate, dogRate, otherRate } = getLifetimeBaseline();
  const rates = { cat: catRate, dog: dogRate, other: otherRate };

  const delta = cachedSeason ? cachedSeason.delta1h : { cat: 0, dog: 0, other: 0 };

  return res.json({
    stats: cachedStats,
    trending: cachedTrending,
    season: cachedSeason ? cachedSeason.season : 'neutral',  // FIXED: Changed from 'N/A' to 'neutral'
    delta, // still "Last Hour" for UI, season uses 24h internally
    performance,
    rates,
    intensityPct: cachedSeason ? cachedSeason.intensityPct : 0,
    lastUpdated: lastStatsUpdate ? new Date(lastStatsUpdate).toISOString() : null
  });
});

app.get('/api/pool-counters', async (req, res) => {
  try {
    const snap = await getPoolSnapshot();
    const windowMetrics = await getPoolWindowMetrics();
    
    // Use first pump event timestamp; else earliest session start; else "now"
    const endTs = nowUtcString();
    let startTs = snap.firstEventTs;
    if (!startTs) {
      const row = await getAsync(`SELECT MIN(start_ts) AS min_ts FROM server_sessions`);
      startTs = (row && row.min_ts) ? row.min_ts : endTs;
    }
    const lifetimeHours = await getActiveHoursRange(startTs, endTs);
    const baselineRate = lifetimeHours > 0 ? (snap.count / lifetimeHours) : 0;
    
    // Calculate if pump.fun is in "season" (>= 1% lift vs baseline)
    const lift = windowMetrics.rate24h - baselineRate;
    const liftPct = baselineRate > 0 ? (lift / baselineRate) * 100 : 0;
        let season = 'neutral';
    let intensityPct = 0;
    if (windowMetrics.count24h >= PUMP_SEASON_MIN_SAMPLES && liftPct >= PUMP_SEASON_LIFT_THRESHOLD) {
      season = 'pump';
      intensityPct = Math.round(liftPct);
    }
    
    res.json({
      total: snap.count,
      baseline: {
        rate: baselineRate.toFixed(2),
        rateUnit: 'per hour'
      },
      window24h: {
        count: windowMetrics.count24h,
        rate: windowMetrics.rate24h.toFixed(2),
        rateUnit: 'per hour'
      },
      liftPct: liftPct.toFixed(1),
      season,
      intensityPct,
      lastUpdated: snap.lastUpdated
    });
  } catch (e) {
    res.status(500).json({ error: 'pool-counters failed', message: String(e) });
  }
});

/** REST: forecast */
app.get('/api/forecast', async (req, res) => {
  const { since } = req.query;
  
  if (since) {
    try {
      const sinceDate = new Date(since);
      if (isNaN(sinceDate.getTime())) {
        return res.status(400).json({ error: 'Invalid date format for since parameter' });
      }
      const sinceTimestamp = sinceDate.toISOString().slice(0, 19).replace('T', ' ');
      const historicalForecasts = await getAllForecastsSince(sinceTimestamp);
      return res.json({ 
        forecasts: historicalForecasts.map(f => ({
          ...f,
          forecast_ts_utc: new Date(f.forecast_ts.replace(' ', 'T') + 'Z').toISOString()
        })),
        lastUpdated: historicalForecasts.length > 0
          ? new Date(historicalForecasts[historicalForecasts.length - 1].forecast_ts.replace(' ', 'T') + 'Z').toISOString()
          : null
      });
    } catch (err) {
      console.error('Error fetching historical forecasts:', err);
      return res.status(500).json({ error: 'Failed to fetch historical forecasts' });
    }
  } else {
    if (!cachedForecasts) {
      return res.status(503).json({ error: 'Forecasts not ready. Forecasts are computed hourly at :02 past the hour.' });
    }
    return res.json({ 
      forecasts: cachedForecasts.map(f => ({
        ...f,
        forecast_ts_utc: new Date(f.forecast_ts.replace(' ', 'T') + 'Z').toISOString()
      })),
      // Prefer per-row generated_at (if schema migrated) else fall back to set-level timestamp
      lastUpdated: (cachedForecasts[0] && cachedForecasts[0].generated_at)
        ? new Date((cachedForecasts[0].generated_at).replace(' ', 'T') + 'Z').toISOString()
        : cachedForecastsGeneratedAt
    });
  }
});

/** REST: Season forecast (next 24 h) */
app.get('/api/season-forecast', async (req, res) => {
  try {
    if (!cachedSeason24hForecast) {
      // Lazy compute if not present (e.g. after restart before :02 tick)
      await calculateSeasonForecast24h();
    }
    if (!cachedSeason24hForecast) {
      return res.status(503).json({ error: 'Season forecast not ready. It is computed hourly at :02.' });
    }
    return res.json(cachedSeason24hForecast);
  } catch (e) {
    console.error('season-forecast route error:', e);
    return res.status(500).json({ error: 'internal error' });
  }
});

/** REST: Season forecast (next 24 h, static) */
app.get('/api/season-forecast-static', async (req, res) => {
  try {
    const qday = (req.query.date || '').trim();
    if (qday) {
      const row = await getSeasonForecastDaily(qday);
      if (!row) return res.status(404).json({ error: `No static forecast for ${qday}` });
      return res.json(mapDailyRow(row));
    }
    const today = new Date().toISOString().slice(0,10);
    // cache hit
    if (cachedSeason24hForecastStatic && cachedSeason24hForecastStaticDay === today) {
      return res.json(cachedSeason24hForecastStatic);
    }
    // fetch or 404 if not yet computed today
    const row = await getSeasonForecastDaily(today);
    if (!row) return res.status(404).json({ error: 'Static forecast not computed yet for today (runs 00:02 UTC).' });
    cachedSeason24hForecastStatic = mapDailyRow(row);
    cachedSeason24hForecastStaticDay = today;
    return res.json(cachedSeason24hForecastStatic);
  } catch (e) {
    console.error('season-forecast-static route error:', e);
    return res.status(500).json({ error: 'internal error' });
  }
});

/**
 * REST: Season images (100% confidence, recent, randomized)
 * UPDATED: Now uses cached data when available
 */
app.get('/api/season-images', async (req, res) => {
  try {
    res.set('Cache-Control', 'no-store');
    const season = String(req.query.season || '').toLowerCase();
    const n = Math.min(Math.max(parseInt(req.query.n, 10) || 50, 1), 50);  // Changed default to 50

    if (!['cat', 'dog', 'other'].includes(season)) {
      return res.status(400).json({ error: 'season must be cat|dog|other' });
    }

    // Check cache (1 minute TTL)
    if (cachedSeasonImages[season] && 
        Date.now() - cachedSeasonImages[season].timestamp < 60000) {
      const images = cachedSeasonImages[season].images.slice(0, n);
      return res.json({ 
        images,
        count: images.length,
        cached: true 
      });
    }
    
    // Generate fresh and cache
    const images = await getSeasonImagePaths(season, n);
    if (images.length > 0) {
      cachedSeasonImages[season] = {
        images,
        timestamp: Date.now()
      };
    }
    
    return res.json({ images, count: images.length });
  } catch (err) {
    console.error('season-images route error:', err);
    return res.status(500).json({ error: 'internal error' });
  }
});

/** Debug endpoint for season computation verification (1h & 24h) */
app.get('/api/debug/season', async (req, res) => {
  try {
    const endTs = getCurrentBucketStart();
    const start1h = new Date(Date.parse(endTs.replace(' ', 'T') + 'Z') - 3600_000)
      .toISOString().slice(0, 19).replace('T', ' ');
    const start24h = new Date(Date.parse(endTs.replace(' ', 'T') + 'Z') - 24 * 3600_000)
      .toISOString().slice(0, 19).replace('T', ' ');
    const { catRate, dogRate, otherRate } = getLifetimeBaseline();
    // 1h
    const lh = await getLastHourCounts();
    const hrs1 = await getActiveHoursRange(start1h, endTs);

    // 24h
    const row24 = await getAsync(`
      SELECT COALESCE(SUM(cat_count),0) AS cat, COALESCE(SUM(dog_count),0) AS dog, COALESCE(SUM(other_count),0) AS other
      FROM time_series_5m WHERE bucket_start >= ? AND bucket_start < ?
    `, [start24h, endTs]);
    const hrs24 = await getActiveHoursRange(start24h, endTs);

    res.json({
      baseline: { catRate, dogRate, otherRate },
      window1h: { startTs: start1h, endTs, hours: hrs1, actual: lh },
      window24h: { startTs: start24h, endTs, hours: hrs24, actual: row24 },
      zScores: cachedSeason ? cachedSeason.zScores : null,
      phi: cachedPhi
    });
  } catch (e) {
    res.status(500).json({ error: 'debug failed' });
  }
});

/** WS: incoming image-prediction updates (same HTTP server / port 3001) */
const wss = new WebSocket.Server({ server });
let localClients = new Set();

function broadcastPrediction(message) {
  localClients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

wss.on('connection', (ws) => {
  localClients.add(ws);
  ws.on('close', () => {
    localClients.delete(ws);
  });
});

async function handleImagePrediction(data) {
  console.log("Received image-prediction:", data);
  latestImagePrediction = data;

  const c = String(data.classification || '').trim().toLowerCase();
  const isCat = c === 'cat';
  const isDog = c === 'dog';
  const isOther = !isCat && !isDog;

  if (isCat) currentBucket.cat++;
  else if (isDog) currentBucket.dog++;
  else currentBucket.other++;
  currentBucket.total++;

  // NEW: pump.fun tracking only
  const poolRaw = String(data.pool || '').trim().toLowerCase();
  const isPump = (poolRaw === 'pump');
  if (isPump) {
    await incrementPoolTotal(1);  // Just increment counter
    // also record into the current 5‑minute bucket
    currentBucket.pump = (currentBucket.pump || 0) + 1;
    await broadcastPoolCountersUpdate();
  }

  if (data.tokenAddress) {
    latestTokenAddresses.push(data.tokenAddress);
    if (latestTokenAddresses.length > 100) latestTokenAddresses.shift();
  }

  broadcastPrediction(JSON.stringify(data));
}

let wsClient;
function connectToOtherBackend() {
  console.log(`Connecting to backend at ${OTHER_BACKEND_WS_URL} (catvsdog-ai-protocol)...`);
  wsClient = new WebSocket(OTHER_BACKEND_WS_URL, 'catvsdog-ai-protocol');

  wsClient.on('open', () => {
    console.log(`Connected to other backend at ${OTHER_BACKEND_WS_URL}`);
  });

  wsClient.on('message', async (data) => {
    try {
      const parsed = JSON.parse(data);
      if (parsed.type === 'image-prediction') {
        await handleImagePrediction(parsed);
      }
    } catch (err) {
      console.error("Error parsing message:", err);
    }
  });

  wsClient.on('error', (err) => {
    console.error("WebSocket client error:", err);
  });

  wsClient.on('close', () => {
    console.warn("Connection closed. Reconnecting in 5s...");
    setTimeout(connectToOtherBackend, 5000);
  });
}

/** WS: stats/tokens/forecast broadcaster (port 8766) */
statsWss.on('connection', async (ws) => {  // Make async
  statsClients.add(ws);
  
  // Send last known daily static forecast on connect (if any) - existing code
  if (cachedSeason24hForecastStatic) {
    try {
      ws.send(JSON.stringify({ type: 'season-forecast-static-update', forecast: cachedSeason24hForecastStatic }));
    } catch (_) {}
  }
  
  // NEW: send pool snapshot right away
  try {
    await broadcastPoolCountersUpdate(ws);  // AWAIT
  } catch (e) {
    console.error('Error sending initial pool counters:', e);
  }
  
  ws.on('close', () => {
    statsClients.delete(ws);
  });
});

function broadcastStatsUpdate(stats) {
  const perfWindow = stats['24h'];
  const safeDivide = (num, den) => den > 0 ? num / den : 0;
  const performance = {
    cat:   safeDivide(perfWindow.actual.cat,   perfWindow.expected.cat),
    dog:   safeDivide(perfWindow.actual.dog,   perfWindow.expected.dog),
    other: safeDivide(perfWindow.actual.other, perfWindow.expected.other)
  };

  const { catRate, dogRate, otherRate } = getLifetimeBaseline();
  const rates = { cat: catRate, dog: dogRate, other: otherRate };

  const delta = cachedSeason ? cachedSeason.delta1h : { cat: 0, dog: 0, other: 0 };

  const msg = JSON.stringify({
    type: 'stats-update',
    stats,
    trending: cachedTrending,
    season: cachedSeason ? cachedSeason.season : 'neutral',
    delta,
    performance,
    rates,
    intensityPct: cachedSeason ? cachedSeason.intensityPct : 0,
    lastUpdated: lastStatsUpdate ? new Date(lastStatsUpdate).toISOString() : null
  });

  statsClients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  });
}

function broadcastTokensUpdate(tokens) {
  const msg = JSON.stringify({ type: 'tokens-update', tokens });
  statsClients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  });
}

// Broadcast pool counters + season signal
async function broadcastPoolCountersUpdate(ws = null) {
  try {
    const snap = await getPoolSnapshot();
    const windowMetrics = await getPoolWindowMetrics();
    
    // Use actual current time for consistency
    const endTs = nowUtcString();
    let startTs = snap.firstEventTs;
    if (!startTs) {
      const row = await getAsync(`SELECT MIN(start_ts) AS min_ts FROM server_sessions`);
      startTs = (row && row.min_ts) ? row.min_ts : endTs;
    }
    const lifetimeHours = await getActiveHoursRange(startTs, endTs);
    const baselineRate = lifetimeHours > 0 ? (snap.count / lifetimeHours) : 0;
    
    const lift = windowMetrics.rate24h - baselineRate;
    const liftPct = baselineRate > 0 ? (lift / baselineRate) * 100 : 0;
    
    let season = 'neutral';
    let intensityPct = 0;
    if (windowMetrics.count24h >= PUMP_SEASON_MIN_SAMPLES && liftPct >= PUMP_SEASON_LIFT_THRESHOLD) {
      season = 'pump';
      intensityPct = Math.round(liftPct);
    }
    
    const payload = JSON.stringify({
      type: 'pool-counters-update',
      total: snap.count,
      baseline: {
        rate: baselineRate.toFixed(2),
        rateUnit: 'per hour'
      },
      window24h: {
        count: windowMetrics.count24h,
        rate: windowMetrics.rate24h.toFixed(2),
        rateUnit: 'per hour'
      },
      liftPct: liftPct.toFixed(1),
      season,
      intensityPct,
      lastUpdated: snap.lastUpdated
    });
    
    if (ws) {
      try { ws.send(payload); } catch {}
      return;
    }
    for (const c of statsClients) {
      try { if (c.readyState === WebSocket.OPEN) c.send(payload); } catch {}
    }
  } catch (e) {
    console.error('broadcastPoolCountersUpdate failed:', e);
  }
}

setInterval(() => {
  if (!cachedStats) return;
  broadcastStatsUpdate(cachedStats);
}, 60_000);

setInterval(() => {
  broadcastTokensUpdate(latestTokenAddresses);
}, 10_000);

// Broadcast pool counters every minute for live updates
setInterval(async () => {
  try {
    await broadcastPoolCountersUpdate();
  } catch (e) {
    console.error('Periodic pool counter broadcast failed:', e);
  }
}, 60_000);

/** Season calc – z-score over last complete 24h; keep 1h deltas for UI */
async function calculateSeason() {
  const { catRate, dogRate, otherRate } = getLifetimeBaseline();
  
  // Define delta1h upfront with zeros to avoid reference errors
  let delta1h = { cat: 0, dog: 0, other: 0 };
  
  const endTs = getCurrentBucketStart();
  const start1h = new Date(Date.parse(endTs.replace(' ', 'T') + 'Z') - 3600_000)
    .toISOString().slice(0, 19).replace('T', ' ');
  const start24h = new Date(Date.parse(endTs.replace(' ', 'T') + 'Z') - 24 * 3600_000)
    .toISOString().slice(0, 19).replace('T', ' ');

  // --- 24h actual & expected (for season decision) ---
  const row24 = await getAsync(`
    SELECT
      COALESCE(SUM(cat_count), 0)   AS cat,
      COALESCE(SUM(dog_count), 0)   AS dog,
      COALESCE(SUM(other_count), 0) AS other
    FROM time_series_5m
    WHERE bucket_start >= ? AND bucket_start < ?
  `, [start24h, endTs]);
  const actual24 = { cat: row24.cat, dog: row24.dog, other: row24.other };
  const hrs24 = await getActiveHoursRange(start24h, endTs);
  const expected24 = {
    cat:   catRate   * hrs24,
    dog:   dogRate   * hrs24,
    other: otherRate * hrs24
  };
  
  // Short-circuit to neutral if no active hours in window
  if (hrs24 <= 0) {
    return {
      season: 'neutral',
      intensityPct: 0,
      delta1h,  // Now safe - defined as zeros above
      delta24h: { cat: 0, dog: 0, other: 0 },
      zScores: { cat: 0, dog: 0, other: 0 },
      window: { startTs24h: start24h, endTs }
    };
  }

  const delta24 = {
    cat:   actual24.cat   - expected24.cat,
    dog:   actual24.dog   - expected24.dog,
    other: actual24.other - expected24.other
  };

  // Compute 1h delta (overwrite the initial zeros)
  const { catCount, dogCount, otherCount } = await getLastHourCounts();
  const hrs1 = await getActiveHoursRange(start1h, endTs);
  const expected1 = { cat: catRate*hrs1, dog: dogRate*hrs1, other: otherRate*hrs1 };
  delta1h = {
    cat: catCount - expected1.cat,
    dog: dogCount - expected1.dog,
    other: otherCount - expected1.other
  };

  // --- refresh dispersion (every 15 min) ---
  if (Date.now() - lastPhiMs > 15 * 60_000) {
    try {
      cachedPhi = await estimateDispersion(48);
      lastPhiMs = Date.now();
    } catch (_) { /* keep previous cachedPhi */ }
  }

  // --- z-scores over 24h ---
  const z = {
    cat:   delta24.cat   / Math.sqrt(Math.max(expected24.cat,   1e-6) * Math.max(cachedPhi.cat,   1)),
    dog:   delta24.dog   / Math.sqrt(Math.max(expected24.dog,   1e-6) * Math.max(cachedPhi.dog,   1)),
    other: delta24.other / Math.sqrt(Math.max(expected24.other, 1e-6) * Math.max(cachedPhi.other, 1))
  };

  // winner by largest positive z; require minimal evidence
  const categories = ['cat', 'dog', 'other'];
  let season = 'neutral';
  let zMax = -Infinity, kMax = null;
  for (const k of categories) { if (z[k] > zMax) { zMax = z[k]; kMax = k; } }
  const thresholdZ = 1.0;
  if (zMax >= thresholdZ) season = kMax;

  // intensity = 24h relative lift of the winner (0..100)
  let intensityPct = 0;
  if (season !== 'neutral' && expected24[season] > 0) {
    intensityPct = Math.max(0, Math.min(100, (delta24[season] / expected24[season]) * 100));
  }

  return {
    season,
    intensityPct,
    delta1h,
    delta24h: delta24,
    zScores: z,
    window: { startTs24h: start24h, endTs }
  };
}

/**
 * Season forecast (next 24 h)
 *  - For each category, sum 24‑step HW forecasts
 *  - UPTIME-AWARE: scale forecasts per hour by uptime fractions; expected = baseline_rate × Σ_uptime
 *  - ẑ = Δ̂ / sqrt(phi × expected)
 *  - Winner = largest positive ẑ ≥ threshold
 */
async function calculateSeasonForecast24h() {
  // refresh dispersion if stale (reuse same cache as actual-season calc)
  if (Date.now() - lastPhiMs > 15 * 60_000) {
    try { cachedPhi = await estimateDispersion(48); lastPhiMs = Date.now(); } catch (_) {}
  }

  const { catRate, dogRate, otherRate } = getLifetimeBaseline();
  const steps = 24; // next 24 complete hours
  // Uptime fractions [0..1] for each of the 24 hours ahead
  const uptime = await getUptimeFractionsNext24(14);
  const expectedActiveHours = uptime.reduce((a,b)=>a+b,0);
  const exp = {
    cat:   catRate   * expectedActiveHours,
    dog:   dogRate   * expectedActiveHours,
    other: otherRate * expectedActiveHours
  }; // expected under baseline × expected uptime

  // Multi‑step HW forecasts per category
  const [fcCat, fcDog, fcOther] = await Promise.all([
    computeHoltWintersMulti('cat', steps).catch(() => null),
    computeHoltWintersMulti('dog', steps).catch(() => null),
    computeHoltWintersMulti('other', steps).catch(() => null)
  ]);
  if (!fcCat || !fcDog || !fcOther) return null;

  // Scale each hourly forecast by the uptime fraction for that hour
  const scaleSum = (points) => points.reduce((s, p, i) => s + p * uptime[i], 0);
  const sum = {
    cat:   scaleSum(fcCat.points),
    dog:   scaleSum(fcDog.points),
    other: scaleSum(fcOther.points)
  };

  const delta = {
    cat:   sum.cat   - exp.cat,
    dog:   sum.dog   - exp.dog,
    other: sum.other - exp.other
  };
  const z = {
    cat:   delta.cat   / Math.sqrt(Math.max(exp.cat,   1e-6) * Math.max(cachedPhi.cat,   1)),
    dog:   delta.dog   / Math.sqrt(Math.max(exp.dog,   1e-6) * Math.max(cachedPhi.dog,   1)),
    other: delta.other / Math.sqrt(Math.max(exp.other, 1e-6) * Math.max(cachedPhi.other, 1))
  };

  // pick winner
  let season = 'neutral';
  let zMax = -Infinity, kMax = null;
  for (const k of ['cat','dog','other']) { if (z[k] > zMax) { zMax = z[k]; kMax = k; } }
  const thresholdZ = 1.0;
  if (zMax >= thresholdZ) season = kMax;

  let intensityPct = 0;
  if (season !== 'neutral' && exp[season] > 0) {
    intensityPct = Math.max(0, Math.min(100, (delta[season] / exp[season]) * 100));
  }

  cachedSeason24hForecast = {
    mode: 'rolling',
    season,
    intensityPct,
    sums: sum,
    expected: exp,
    delta,
    zScores: z,
    steps,
    timestamp: new Date().toISOString()
  };
  return cachedSeason24hForecast;
}


/**
 * Season forecast (next 24 h, STATIC for today)
 *  - Same calculation as the rolling forecast
 *  - Run once at 00:02 UTC; persisted immutably
 *  - UPTIME-AWARE: store *scaled* per-hour points (already multiplied by uptime fractions)
 */
async function calculateSeasonForecast24hStatic() {
  if (Date.now() - lastPhiMs > 15 * 60_000) {
    try { cachedPhi = await estimateDispersion(48); lastPhiMs = Date.now(); } catch (_) {}
  }
  const { catRate, dogRate, otherRate } = getLifetimeBaseline();
  const steps = 24;
  // Uptime-aware expected active hours
  const uptime = await getUptimeFractionsNext24(14);
  const expectedActiveHours = uptime.reduce((a,b)=>a+b,0);
  const exp = {
    cat:   catRate   * expectedActiveHours,
    dog:   dogRate   * expectedActiveHours,
    other: otherRate * expectedActiveHours
  };

  const [fcCat, fcDog, fcOther] = await Promise.all([
    computeHoltWintersMulti('cat', steps).catch(() => null),
    computeHoltWintersMulti('dog', steps).catch(() => null),
    computeHoltWintersMulti('other', steps).catch(() => null)
  ]);
  if (!fcCat || !fcDog || !fcOther) return null;

  // Scale each hourly forecast point by uptime; also return scaled points
  const scalePoints = (points) => points.map((p, i) => p * uptime[i]);
  const points = {
    cat:   scalePoints(fcCat.points),
    dog:   scalePoints(fcDog.points),
    other: scalePoints(fcOther.points)
  };
  const sum = {
    cat:   points.cat.reduce((a,b)=>a+b,0),
    dog:   points.dog.reduce((a,b)=>a+b,0),
    other: points.other.reduce((a,b)=>a+b,0)
  };

  const delta = {
    cat:   sum.cat   - exp.cat,
    dog:   sum.dog   - exp.dog,
    other: sum.other - exp.other
  };
  const z = {
    cat:   delta.cat   / Math.sqrt(Math.max(exp.cat,   1e-6) * Math.max(cachedPhi.cat,   1)),
    dog:   delta.dog   / Math.sqrt(Math.max(exp.dog,   1e-6) * Math.max(cachedPhi.dog,   1)),
    other: delta.other / Math.sqrt(Math.max(exp.other, 1e-6) * Math.max(cachedPhi.other, 1))
  };
  let season = 'neutral';
  let zMax = -Infinity, kMax = null;
  for (const k of ['cat','dog','other']) { if (z[k] > zMax) { zMax = z[k]; kMax = k; } }
  if (zMax >= 1.0) season = kMax;
  let intensityPct = 0;
  if (season !== 'neutral' && exp[season] > 0) {
    intensityPct = Math.max(0, Math.min(100, (delta[season] / exp[season]) * 100));
  }

  return {
    mode: 'static',
    season,
    intensityPct,
    sums: sum,
    expected: exp,
    delta,
    zScores: z,
    steps,
    forecast_ts_start: fcCat.forecast_ts_start, // all three share the same start
    points, // scaled points (uptime-adjusted)
    timestamp: new Date().toISOString()
  };
}