// aiScript.js
// Production console suppression for catvsdogai
(function() {
  // Check if we're in production (allow debug override)
  const isProdHost = ['catvsdog.ai', 'catvsdog.live'].includes(window.location.hostname);
  const debugOverride = /\bdebug=1\b/.test(window.location.search) || window.__ALLOW_CONSOLE__ === true;
  const isProduction = isProdHost && !debugOverride;
  
  if (isProduction) {
    // Leave a single message BEFORE limiting console (warn/error stay enabled)
    console.log('%c🔥 catvsdog.ai Console limited (warn/error still enabled)', 
                'color: red; font-weight: bold;');
    
    const noop = () => {};
    // Silence only noisy methods; keep warn/error/assert/time for observability
    const methods = ['log', 'debug', 'info', 'trace', 'dir'];
    
    methods.forEach(method => {
      if (typeof console[method] === 'function') {
        console[method] = noop;
      }
    });
  }
})();

document.addEventListener("DOMContentLoaded", () => {
  // --- Season Banner config & state ---
  const MAX_VISIBLE_CIRCLES = 5;      // render exactly five circles
  const ROTATE_INTERVAL_MS = 5000;    // change images every 5s

  let currentSeason = null;
  let imagePool = [];
  let rotateTimer = null;

  /**
   * Update stat card elements using aggregated stats (only Cat and Dog).
   */
  function updateStatsDisplay(stats) {
    for (const [windowLabel, windowData] of Object.entries(stats)) {
      const card = document.getElementById(`card-${windowLabel}`);
      
      if (card && windowData.actual) {
        const catSpan = card.querySelector(".cat-count");
        const dogSpan = card.querySelector(".dog-count");
        
        // Store previous values
        const prevCatValue = catSpan ? parseInt(catSpan.textContent, 10) : 0;
        const prevDogValue = dogSpan ? parseInt(dogSpan.textContent, 10) : 0;
        
        // Update values and animate if changed
        if (catSpan) {
          catSpan.textContent = windowData.actual.cat;
          if (prevCatValue !== windowData.actual.cat) {
            animateValueChange(catSpan);
          }
        }
        
        if (dogSpan) {
          dogSpan.textContent = windowData.actual.dog;
          if (prevDogValue !== windowData.actual.dog) {
            animateValueChange(dogSpan);
          }
        }
      }
    }
  }

  function animateValueChange(element) {
    element.classList.remove('count-updated');
    void element.offsetWidth; // Force reflow
    element.classList.add('count-updated');
  }

  /**
   * Display trending info in each time window card (Stable, Up, Down).
   */
  function updateTrendingDisplay(trending) {
    for (const [windowLabel, trendData] of Object.entries(trending)) {
      const catTrendElement = document.getElementById(`trending-${windowLabel}-cat`);
      const dogTrendElement = document.getElementById(`trending-${windowLabel}-dog`);
      
      if (catTrendElement) {
        const prevTrendText = catTrendElement.textContent;
        catTrendElement.textContent = trendData.cat;
        updateTrendClass(catTrendElement, trendData.cat);
        
        if (prevTrendText !== trendData.cat) {
          animateTrendChange(catTrendElement);
        }
      }
      
      if (dogTrendElement) {
        const prevTrendText = dogTrendElement.textContent;
        dogTrendElement.textContent = trendData.dog;
        updateTrendClass(dogTrendElement, trendData.dog);
        
        if (prevTrendText !== trendData.dog) {
          animateTrendChange(dogTrendElement);
        }
      }
    }
  }

  function updateTrendClass(element, trendText) {
    element.classList.remove('trend-up', 'trend-down', 'trend-stable');
    if (trendText.includes('Up') || trendText.includes('🚀')) {
      element.classList.add('trend-up');
    } else if (trendText.includes('Down') || trendText.includes('📉')) {
      element.classList.add('trend-down');
    } else {
      element.classList.add('trend-stable');
    }
  }

  function animateTrendChange(element) {
    element.classList.remove('trend-changed');
    void element.offsetWidth; // reflow
    element.classList.add('trend-changed');
  }

  function updateSeasonDisplay(data) {
    const {
      season,
      stats: statsData,
      delta,
      performance,
      rates,
      intensityPct,
      lastUpdated
    } = data;
    
    // Elements
    const seasonEl   = document.getElementById("season-display");
    const updatedEl  = document.getElementById("season-updated");
    const emojiEl    = document.getElementById("season-emoji");
    const bannerEl   = document.getElementById("season-banner");
    
    const deltaCatEl   = document.getElementById("delta-cat");
    const deltaDogEl   = document.getElementById("delta-dog");
    const deltaOtherEl = document.getElementById("delta-other");
    
    const perfCatEl    = document.getElementById("perf-cat");
    const perfDogEl    = document.getElementById("perf-dog");
    const perfOtherEl  = document.getElementById("perf-other");
    
    const rateCatEl    = document.getElementById("rate-cat");
    const rateDogEl    = document.getElementById("rate-dog");
    const rateOtherEl  = document.getElementById("rate-other");
    
    // Bail if any are missing (removed ratioEl from check)
    if (!seasonEl || !updatedEl || !emojiEl || !bannerEl
        || !deltaCatEl || !deltaDogEl || !deltaOtherEl
        || !perfCatEl || !perfDogEl || !perfOtherEl
        || !rateCatEl || !rateDogEl || !rateOtherEl) {
      return;
    }
    
    // 1) Timestamp from server
    updatedEl.textContent = new Date(lastUpdated).toLocaleTimeString();
    
    // 2) Update deltas
    deltaCatEl.textContent   = `${delta.cat >= 0 ? "+" : ""}${Math.round(delta.cat)}`;
    deltaDogEl.textContent   = `${delta.dog >= 0 ? "+" : ""}${Math.round(delta.dog)}`;
    deltaOtherEl.textContent = `${delta.other >= 0 ? "+" : ""}${Math.round(delta.other)}`;
    
    // 3) Update performance %
    perfCatEl.textContent   = `${(performance.cat * 100).toFixed(0)}%`;
    perfDogEl.textContent   = `${(performance.dog * 100).toFixed(0)}%`;
    perfOtherEl.textContent = `${(performance.other * 100).toFixed(0)}%`;
    
    // 4) Update baseline rates
    rateCatEl.textContent   = rates.cat.toFixed(2);
    rateDogEl.textContent   = rates.dog.toFixed(2);
    rateOtherEl.textContent = rates.other.toFixed(2);
	
	// Pulse metric cells to reflect updates (CSS: .value-updated)
    const pulse = (el) => { el.classList.remove('value-updated'); void el.offsetWidth; el.classList.add('value-updated'); };
    [
      perfCatEl,  perfDogEl,  perfOtherEl,
      deltaCatEl, deltaDogEl, deltaOtherEl,
      rateCatEl,  rateDogEl,  rateOtherEl
    ].forEach(pulse);
    
    // 5) Season text & emoji
    const seasonLabels = {
      neutral: "There's currently no season",
      cat:  "It's cat season!",
      dog:  "It's dog season!",
      other: "Others have taken over 😞 "
    };
    
    const displayText = seasonLabels[season] || seasonLabels.neutral;
    seasonEl.textContent = displayText;
    
    // Ensure neutral banner base class without wiping other classes
    if (!bannerEl.classList.contains('season-banner')) {
      bannerEl.classList.add('season-banner');
    }
    // (No theme classes added intentionally)
    switch (season) {
      case "cat":   emojiEl.textContent = "🐱"; break;
      case "dog":   emojiEl.textContent = "🐶"; break;
      case "other": emojiEl.textContent = "💩"; break;
      default:      emojiEl.textContent = "🤷";
    }
    
    // 6) Trigger banner animation
    bannerEl.classList.remove("season-update");
    void bannerEl.offsetWidth;
    bannerEl.classList.add("season-update");
    
    // 7) Update intensity bar
	const bar  = document.getElementById("intensity-bar");
	const text = document.getElementById("intensity-text");
	if (bar && text) {
	  bar.style.width      = `${intensityPct}%`;
	  text.textContent     = `${Math.round(intensityPct)}%`;  // ← ROUNDED HERE
	}
    
    // 8) Sync mobile values
    const mobileElements = {
      'perf-cat-m': perfCatEl.textContent,
      'perf-dog-m': perfDogEl.textContent,
      'perf-other-m': perfOtherEl.textContent,
      'delta-cat-m': deltaCatEl.textContent,
      'delta-dog-m': deltaDogEl.textContent,
      'delta-other-m': deltaOtherEl.textContent,
      'rate-cat-m': rateCatEl.textContent,
      'rate-dog-m': rateDogEl.textContent,
      'rate-other-m': rateOtherEl.textContent
    };

    for (const [id, value] of Object.entries(mobileElements)) {
      const el = document.getElementById(id);
      if (el) el.textContent = value;
    }

    // 9) Track season change but don't fetch - wait for WebSocket or initial load
    if (['cat','dog','other'].includes(season)) {
      if (currentSeason !== season) {
        currentSeason = season;
        // Request initial images via REST only if we don't have any
        if (!imagePool.length) {
          loadSeasonImages(season, 50);
        }
      }
    }
  }
  
  /**
   * Render the Season forecast (next 24 h, rolling) badge
   */
  function updateSeasonForecastDisplay(payload) {
    const data = payload && payload.forecast ? payload.forecast : payload;
    if (!data) return;
    const emojiMap = { cat: '🐱', dog: '🐶', other: '💩', neutral: '🤷' };
    const emojiEl = document.getElementById('season-forecast-emoji');
    const textEl  = document.getElementById('season-forecast-text');
    const confEl  = document.getElementById('season-forecast-confidence');
    const tsEl    = document.getElementById('season-forecast-ts');
    const dCatEl  = document.getElementById('sf-delta-cat');
    const dDogEl  = document.getElementById('sf-delta-dog');
    const dOthEl  = document.getElementById('sf-delta-other');
    if (!emojiEl || !textEl || !confEl || !tsEl || !dCatEl || !dDogEl || !dOthEl) return;

    const season = data.season || 'neutral';
    emojiEl.textContent = emojiMap[season] || '🤷';
    textEl.textContent = season === 'neutral'
      ? 'No clear leader for the next 24‍h'
      : `Likely ${season} season in the next 24‍h`;

    const winner = season !== 'neutral' ? season : null;
    const z = data.zScores || {};
    const zStr = winner ? `z≈${(z[winner] ?? 0).toFixed(2)}` : '';
    const intens = data.intensityPct != null ? `${Math.round(data.intensityPct)}% lift` : '';
    confEl.textContent = [zStr, intens].filter(Boolean).join(' · ');

    dCatEl.textContent = `${data.delta && data.delta.cat >= 0 ? '+' : ''}${Math.round(data.delta?.cat ?? 0)}`;
    dDogEl.textContent = `${data.delta && data.delta.dog >= 0 ? '+' : ''}${Math.round(data.delta?.dog ?? 0)}`;
    dOthEl.textContent = `${data.delta && data.delta.other >= 0 ? '+' : ''}${Math.round(data.delta?.other ?? 0)}`;
    tsEl.textContent = new Date(data.timestamp || Date.now()).toLocaleTimeString();
  }  

  /**
   * Render the Season forecast (next 24 h, static) badge
   * Uses the same visual grammar as the rolling card but with -static- DOM ids.
   * Assumes backend REST at /ai/api/season-forecast-static and WS type 'season-forecast-static-update'.
   */
  function updateSeasonForecastStaticDisplay(payload) {
    const data = payload && payload.forecast ? payload.forecast : payload;
    if (!data) return;
    const emojiMap = { cat: '🐱', dog: '🐶', other: '💩', neutral: '🤷' };
    const emojiEl = document.getElementById('season-forecast-emoji-static');
    const textEl  = document.getElementById('season-forecast-text-static');
    const confEl  = document.getElementById('season-forecast-confidence-static');
    const tsEl    = document.getElementById('season-forecast-ts-static');
    const dCatEl  = document.getElementById('sf-static-delta-cat');
    const dDogEl  = document.getElementById('sf-static-delta-dog');
    const dOthEl  = document.getElementById('sf-static-delta-other');
    if (!emojiEl || !textEl || !confEl || !tsEl || !dCatEl || !dDogEl || !dOthEl) return;

    const season = data.season || 'neutral';
    emojiEl.textContent = emojiMap[season] || '🤷';
    textEl.textContent = season === 'neutral' ? 'No clear leader for the next 24‍h' : `Likely ${season} season in the next 24‍h`;

    const winner = season !== 'neutral' ? season : null;
    const z = data.zScores || {};
    const zStr = winner ? `z≈${(z[winner] ?? 0).toFixed(2)}` : '';
    const intens = data.intensityPct != null ? `${Math.round(data.intensityPct)}% lift` : '';
    confEl.textContent = [zStr, intens].filter(Boolean).join(' · ');

    dCatEl.textContent = `${data.delta && data.delta.cat >= 0 ? '+' : ''}${Math.round(data.delta?.cat ?? 0)}`;
    dDogEl.textContent = `${data.delta && data.delta.dog >= 0 ? '+' : ''}${Math.round(data.delta?.dog ?? 0)}`;
    dOthEl.textContent = `${data.delta && data.delta.other >= 0 ? '+' : ''}${Math.round(data.delta?.other ?? 0)}`;
    tsEl.textContent = new Date(data.timestamp || Date.now()).toLocaleTimeString();
  }

  // ---------------------------------------------------------------------
  // Season images - initial load only (updates come via WebSocket)
  // ---------------------------------------------------------------------
  async function loadSeasonImages(season, n = 50) {
    try {
      const res = await fetch(`/ai/api/season-images?season=${encodeURIComponent(season)}&n=${n}`, { cache: 'no-store' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const payload = await res.json();
      const urls = Array.isArray(payload.images) ? payload.images : [];
      if (urls.length > 0) {
        setCircleImages(urls, season);
      } else {
        stopImageRotation();
      }
    } catch (e) {
      console.error('Failed to load season images:', e);
      stopImageRotation();
    }
  }

  function setCircleImages(urls = [], season = 'neutral') {
    const container = document.querySelector('#season-banner .circle-container');
    if (!container) return;

    // Update pool
    imagePool = Array.isArray(urls) ? urls.slice() : [];
    if (!imagePool.length) {
      stopImageRotation();
      container.innerHTML = '';
      return;
    }

    // Ensure exactly five circles exist
    let circles = Array.from(container.querySelectorAll('.circle'));
    if (circles.length !== MAX_VISIBLE_CIRCLES) {
      container.innerHTML = '';
      for (let i = 0; i < MAX_VISIBLE_CIRCLES; i++) {
		const wrap = document.createElement('div');
		wrap.className = 'circle';
		wrap.dataset.index = String(i);
		wrap.style.order = String(i);  
		// Decorative wrapper: not keyboard-focusable
		wrap.setAttribute('aria-hidden', 'true');
        const img = document.createElement('img');
        img.alt = ''; // decorative image
        img.loading = 'lazy';
        img.decoding = 'async';
        wrap.appendChild(img);
        container.appendChild(wrap);
      }
      circles = Array.from(container.querySelectorAll('.circle'));
    } else {
      // Update alt text if season changed
      circles.forEach(c => {
        const img = c.querySelector('img');
        if (img) img.alt = '';
      });
    }

    // Initial fill
    const imgs = circles.map(c => c.querySelector('img')).filter(Boolean);
    for (let i = 0; i < imgs.length; i++) {
      const url = pickRandomFromPool();
      if (url) imgs[i].src = url;
    }

    // Warm up caches
    preloadImages(imagePool.slice(0, 20)); // Preload first 20 to avoid too much memory

    // Start rotation
    startImageRotation();
  }

  function pickRandomFromPool() {
    if (!imagePool.length) return null;
    const idx = Math.floor(Math.random() * imagePool.length);
    return imagePool[idx];
  }

  function rotateAllCircles() {
    const container = document.querySelector('#season-banner .circle-container');
    if (!container || !imagePool.length) return;
    const imgs = Array.from(container.querySelectorAll('.circle img'));
    if (!imgs.length) return;
    
    for (const img of imgs) {
      const nextUrl = pickRandomFromPool();
      if (!nextUrl) continue;
      // Compare absolute URLs to avoid false negatives when one is relative
      try {
        const abs = new URL(nextUrl, window.location.origin).href;
        if (img.src === abs) continue;
      } catch (_) {
        /* ignore URL parse errors and proceed */
      }
      
      img.style.transition = 'opacity 0.25s ease';
      img.style.opacity = '0';
      
      const apply = () => {
        img.onload = () => { 
          img.style.opacity = '1'; 
          img.onload = null; 
        };
        img.src = nextUrl;
      };
      
      const prefersReduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (prefersReduced) {
        apply();
      } else {
        setTimeout(apply, 200);
      }
    }
  }

  function startImageRotation() {
    stopImageRotation();
    rotateAllCircles(); // immediate refresh
    rotateTimer = setInterval(rotateAllCircles, ROTATE_INTERVAL_MS);
  }

  function stopImageRotation() {
    if (rotateTimer) {
      clearInterval(rotateTimer);
      rotateTimer = null;
    }
  }

  function preloadImages(urls) {
    for (const u of urls) {
      const img = new Image();
      img.src = u;
    }
  }

  // 8) Update accessibility attributes based on viewport
  function updateAriaAttributes() {
    const isMobile = window.innerWidth <= 480;
    const table = document.querySelector('.metrics-table');
    const mobileView = document.querySelector('.metrics-mobile');
    
    if (table) {
      table.toggleAttribute('inert', isMobile);
      table.setAttribute('aria-hidden', isMobile ? 'true' : 'false');
    }
    
    if (mobileView) {
      mobileView.toggleAttribute('inert', !isMobile);
      mobileView.setAttribute('aria-hidden', isMobile ? 'false' : 'true');
    }
  }

  // Call on load and resize
  updateAriaAttributes();
  window.addEventListener('resize', updateAriaAttributes, { passive: true });

  /**
   * Update the scrolling tokens display
   */
  function updateTokensDisplay(tokenArray) {
    console.log("Updating tokens display:", tokenArray);
    const container = document.getElementById("scrolling-tokens");
    if (!container || !Array.isArray(tokenArray)) return;

    const tokenText = tokenArray.join(" | ");
    let p = container.querySelector("p");
    if (!p) {
      p = document.createElement("p");
      container.appendChild(p);
    }
    let span = p.querySelector(".token-text");
    if (!span) {
      span = document.createElement("span");
      span.classList.add("token-text");
      p.appendChild(span);
    }
    if (span.textContent.trim() === "") {
      span.textContent = tokenText;
      span.style.opacity = 1;
    } else {
      span.style.transition = "opacity 0.5s ease-out";
      span.style.opacity = 0;
      setTimeout(() => {
        span.textContent = tokenText;
        span.style.opacity = 1;
      }, 500);
    }
  }

  /**
   * Update the button with a formatted prediction message (XSS-safe)
   * - Avoids innerHTML to prevent injection
   * - Preserves .btn-message and .token-ticker hooks
   * - Re-triggers the CSS flash animation
   */
  function updateButtonWithPrediction(data) {
    const btn = document.querySelector(".btn");
    if (!btn) return;

    // Normalize + classify
    const classification = String(data.classification || "").trim().toLowerCase();
    const cls   = classification === "dog" ? "dog" : classification === "cat" ? "cat" : "other";
    const emoji = cls === "dog" ? "🐶" : cls === "cat" ? "🐱" : "💩";

    // Ticker as plain text (cap length to avoid layout blowups)
    const tickerText = String(data.tokenTicker || "").slice(0, 64);

    // Build message safely with text nodes
    const msg = document.createElement("span");
    msg.className = "btn-message";

    const lead   = document.createTextNode("I've just processed a token called ");
    const ticker = document.createElement("span");
    ticker.className = "token-ticker";
    ticker.textContent = tickerText;

    const tail   = document.createTextNode(` — it's a ${cls}! ${emoji}`);

    msg.replaceChildren(lead, ticker, tail);
    btn.replaceChildren(msg);

    // Re-trigger CSS flash animation
    btn.classList.remove("btn-flash");
    void btn.offsetWidth; // reflow
    btn.classList.add("btn-flash");
  }
  
  /**
   * Renders the 3 forecast cards and timestamp
   */
  function updateForecastDisplay(forecasts = [], timestamp = null) {
    // guard against missing or empty forecasts
    if (!Array.isArray(forecasts) || forecasts.length === 0) return;

    forecasts.forEach(f => {
      // category is 'cat' | 'dog' | 'other'
      const pointEl = document.getElementById(`forecast-${f.category}-point`);
      const lowerEl = document.getElementById(`forecast-${f.category}-lower`);
      const upperEl = document.getElementById(`forecast-${f.category}-upper`);
	  if (pointEl) pointEl.textContent = Math.round(f.point);
      if (lowerEl) lowerEl.textContent = Math.round(f.lower_ci);
	  if (upperEl) upperEl.textContent = Math.round(f.upper_ci);
    });
    const tsEl = document.getElementById('forecast-ts');
    if (tsEl && timestamp) {
      const d = timestamp.includes('T') ? new Date(timestamp)
                                        : new Date(timestamp.replace(' ', 'T') + 'Z');
      tsEl.textContent = isNaN(d) ? '--' : d.toLocaleTimeString();
    }
  }

  // ---------------------------------------------------------------------
  // INITIAL REST FETCHES
  // ---------------------------------------------------------------------
Promise.all([
  fetch("/ai/api/stats").then(res => res.json()),
  fetch("/ai/api/latest-tokens").then(res => res.json()),
  fetch("/ai/api/latest").then(res => res.json()),
  fetch("/ai/api/forecast").then(res => res.json()),
  fetch("/ai/api/season-forecast").then(res => res.json()).catch(() => null),
  fetch("/ai/api/season-forecast-static").then(res => res.json()).catch(() => null),
  fetch("/ai/api/pool-counters").then(res => res.json()).catch(() => null)
])
.then(([statsData, tokensData, latestData, forecastData, seasonForecastData, seasonForecastStaticData, poolCounters]) => {
    // 1) Stats
    console.log("Initial stats load:", statsData);
    window.lastStatsUpdate = statsData.lastUpdated;
    if (statsData.stats)    updateStatsDisplay(statsData.stats);
    if (statsData.trending) updateTrendingDisplay(statsData.trending);
    if (statsData.season)   updateSeasonDisplay(statsData);

    // 2) Tokens
    updateTokensDisplay(tokensData);

    // 3) Latest prediction
    if (latestData.tokenTicker) {
      updateButtonWithPrediction(latestData);
    }

    // 4) Forecast
    // Only render when forecasts array exists and has data
    if (Array.isArray(forecastData.forecasts) && forecastData.forecasts.length) {
      updateForecastDisplay(forecastData.forecasts, forecastData.lastUpdated);
    } else {
      console.warn("Forecast data not ready, skipping initial forecast render");
    }
	
    // 5) Season forecast (next 24 h, rolling)
    if (seasonForecastData && seasonForecastData.season) {
      updateSeasonForecastDisplay(seasonForecastData);
    }
    // 6) Season forecast (next 24 h, static)
    if (seasonForecastStaticData && seasonForecastStaticData.season) {
      updateSeasonForecastStaticDisplay(seasonForecastStaticData);
    }

    // 7) Initial pool counters (if available)
  if (poolCounters && poolCounters.total !== undefined) {
    updatePoolCounters(poolCounters);
  }
})
.catch(err => console.error("Error in initial REST fetches:", err));

  // ---------------------------------------------------------------------
  // WEBSOCKET FOR STATS + TOKENS (port 8766)
  // ---------------------------------------------------------------------
  function connectStatsWebSocket() {
    const protocol = window.location.protocol === "https:" ? "wss" : "ws";
    const host     = window.location.host;            // includes port if any
    // proxy via nginx at /ai/ws/
    const wsUrl    = `${protocol}://${host}/ai/ws/`;
    const statsWs  = new WebSocket(wsUrl);

    statsWs.onopen = () => {
      console.log("Connected to stats/tokens WebSocket at", wsUrl);
    };

    statsWs.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        // For a stats update
        if (data.type === "stats-update" && data.stats) {
          console.log("Received stats update (WS):", data);

          // Store the last update timestamp globally
          window.lastStatsUpdate = Date.now();

          // 1) Update aggregated stat cards
          updateStatsDisplay(data.stats);

          // 2) Update trending indicators
          if (data.trending) {
            updateTrendingDisplay(data.trending);
          }

          // 3) Update season banner + details
          if (data.season) {
            updateSeasonDisplay(data);
          }
        }
        // For a tokens update
        else if (data.type === "tokens-update" && data.tokens) {
          console.log("Received tokens update (WS):", data.tokens);
          updateTokensDisplay(data.tokens);
        }
        // For forecast updates (hourly at :02)
        else if (data.type === "forecast-update" && data.forecasts) {
          console.log("Received forecast update (WS):", data);
          updateForecastDisplay(data.forecasts, data.timestamp);
        }
        // Season forecast (next 24 h, rolling)
        else if (data.type === "season-forecast-update" && data.forecast) {
          console.log("Received season-forecast update (WS):", data);
          updateSeasonForecastDisplay(data);
        }
        // Season forecast (next 24 h, static)
        else if (data.type === "season-forecast-static-update" && data.forecast) {
          console.log("Received season-forecast STATIC update (WS):", data);
          updateSeasonForecastStaticDisplay(data);
        }
		
		// NEW: live pool counters
		else if (data.type === "pool-counters-update" && data.total !== undefined) {
		  updatePoolCounters(data);
		}
				
        // Handle season images pushed from backend
        else if (data.type === 'season-images-update' && data.images) {
          console.log(`Received ${data.images.length} ${data.season} image paths (WS)`);
          if (data.season === currentSeason) {
            imagePool = data.images;
            if (!rotateTimer) {
              // First time setup
              setCircleImages(data.images, data.season);
            }
            // Pool is refreshed, rotation continues with new images
          }
        }
      } catch (err) {
        console.error("Error parsing stats/tokens WS message:", err);
      }
    };

    statsWs.onerror = (err) => {
      console.error("Stats/Tokens WebSocket error:", err);
    };

    statsWs.onclose = () => {
      console.warn("Stats/Tokens WebSocket closed. Reconnecting in 5 seconds...");
      setTimeout(connectStatsWebSocket, 5000);
    };
  }

  connectStatsWebSocket();

  // ---------------------------------------------------------------------
  // WEBSOCKET FOR LATEST PREDICTIONS (port 3001)
  // ---------------------------------------------------------------------
  function connectPredictionWebSocket() {
    const protocol = window.location.protocol === "https:" ? "wss" : "ws";
    const host  = window.location.host;         
    const wsUrl = `${protocol}://${host}/ai/predict-ws/`;
    const predictionWs = new WebSocket(wsUrl);

    predictionWs.onopen = () => {
      console.log("Connected to prediction WebSocket at", wsUrl);
    };

    predictionWs.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (!data.type || data.type === "image-prediction") {
          console.log("Real-time prediction (WS):", data);
          updateButtonWithPrediction(data);
        }
      } catch (err) {
        console.error("Error parsing prediction WS message:", err);
      }
    };

    predictionWs.onerror = (err) => {
      console.error("Prediction WebSocket error:", err);
    };

    predictionWs.onclose = () => {
      console.warn("Prediction WebSocket closed. Reconnecting in 5 seconds...");
      setTimeout(connectPredictionWebSocket, 5000);
    };
  }
  connectPredictionWebSocket();

function updatePoolCounters(payload) {
  try {
    const { total, baseline, window24h, liftPct, season, intensityPct } = payload;
    
    // Update DOM elements
    const countEl = document.getElementById('pool-pump-count');
    const baselineEl = document.getElementById('pool-pump-baseline');
    const window24hEl = document.getElementById('pool-pump-window');
    const liftEl = document.getElementById('pool-pump-lift');
    const seasonLine = document.getElementById('pool-season-line');
    const cardPump = document.getElementById('card-pump');
    
    if (!countEl || !baselineEl || !window24hEl || !liftEl || !seasonLine) return;

    // Update displayed values
    countEl.textContent = total ?? 0;
    baselineEl.textContent = `Baseline: ${baseline?.rate ?? 0} tokens/hr`;
    window24hEl.textContent = `24h: ${window24h?.count ?? 0} tokens (${window24h?.rate ?? 0}/hr)`;
    
    // Show lift percentage with appropriate styling
    const lift = parseFloat(liftPct || 0);
    const liftSign = lift >= 0 ? '+' : '';
    liftEl.textContent = `${liftSign}${lift.toFixed(1)}% vs baseline`;
    
    // Style lift based on positive/negative
    if (lift > 0) {
      liftEl.style.color = '#10b981'; // green for positive
    } else if (lift < 0) {
      liftEl.style.color = '#ef4444'; // red for negative
    } else {
      liftEl.style.color = 'rgba(255, 255, 255, 0.75)'; // neutral
    }
    
    // Highlight card if in pump season
    cardPump?.classList.remove('leading');
    if (season === 'pump') {
      cardPump?.classList.add('leading');
    }

    // Update season line
    if (season === 'pump') {
      seasonLine.textContent = `🔥 Pump.fun season detected! (${intensityPct || 0}% lift vs baseline over last 24 hours)`;
      seasonLine.style.color = '#10b981';
    } else {
      seasonLine.textContent = `Normal pump.fun activity levels`;
      seasonLine.style.color = 'rgba(255, 255, 255, 0.75)';
    }
  } catch (e) {
    console.warn('updatePoolCounters failed:', e);
  }
}

// --- Robust FLIP position swapper for season circles ---
(() => {
  const container = document.querySelector('#season-banner .circle-container');
  if (!container) return;

  let swapTimer = null;
  const SWAP_EVERY_MS = 1000;
  const DURATION_MS = 800;
  const EASE = 'ease';

  const prefersReduced = window.matchMedia &&
                         window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function ensureOrders() {
    const circles = Array.from(container.querySelectorAll('.circle'));
    circles.forEach((el, idx) => {
      if (el.style.order === '') el.style.order = String(idx);
    });
    return circles;
  }

  function flipSwapOnce() {
    if (prefersReduced || document.hidden) return;

    const circles = ensureOrders();
    if (circles.length < 2) return;

    const i = Math.floor(Math.random() * circles.length);
    let j = Math.floor(Math.random() * circles.length);
    if (j === i) j = (j + 1) % circles.length;

    const elA = circles[i];
    const elB = circles[j];

    const firstRects = circles.map(el => el.getBoundingClientRect());

    const oa = elA.style.order; 
    const ob = elB.style.order;
    elA.style.order = ob; 
    elB.style.order = oa;

    const lastRects = circles.map(el => el.getBoundingClientRect());

    circles.forEach((el, idx) => {
      const dx = firstRects[idx].left - lastRects[idx].left;
      const dy = firstRects[idx].top  - lastRects[idx].top;
      el.style.transition = 'transform 0s';
	  // Compose via CSS var instead of overriding the whole transform
      el.style.setProperty('--flip-t', `translate3d(${dx}px, ${dy}px, 0)`);
    });

    void container.offsetWidth;

    requestAnimationFrame(() => {
      circles.forEach(el => {
        el.style.transition = `transform ${DURATION_MS}ms ${EASE}`;
        // Animate back to identity w/o clobbering hover scale
        el.style.setProperty('--flip-t', 'translate3d(0,0,0)');
      });
    });
  }

  function maybeStart() {
    if (swapTimer || prefersReduced) return;
    if (container.children.length >= 2) {
      swapTimer = setInterval(flipSwapOnce, SWAP_EVERY_MS);
    }
  }

  function stop() {
    if (swapTimer) {
      clearInterval(swapTimer);
      swapTimer = null;
    }
  }

  const mo = new MutationObserver(() => {
    ensureOrders();
    maybeStart();
    if (container.children.length < 2) stop();
  });
  mo.observe(container, { childList: true });

  ensureOrders();
  maybeStart();

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop(); else maybeStart();
  });
})();
}); 